<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/Core/Bootstrap.php';
\EstoqueMed\Core\Bootstrap::init();
?><!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#0b2445"><meta name="description" content="EstoqueMed_Mb | Controle de medicamentos, lotes, previsão de consumo e compras"><title>EstoqueMed_Mb | Gestão de Medicamentos e Compras</title><link rel="icon" type="image/png" href="assets/images/icone_sistema.png"><link rel="stylesheet" href="assets/css/app.css?v=20261114c"></head>
<body><div id="root"><div class="splash"><div class="splash-logo"><img src="assets/images/logo_oficial.png" alt="EstoqueMed_Mb"></div><p>Gestão de estoque, conservação e compras em um só lugar.</p><div class="loader"></div></div></div><div id="modal-root"></div><div id="toast-root" aria-live="polite"></div><script src="assets/js/app.js?v=20261114c" defer></script></body></html>
