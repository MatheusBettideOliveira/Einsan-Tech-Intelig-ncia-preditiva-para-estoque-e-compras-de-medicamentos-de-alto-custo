<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/Core/Bootstrap.php';
\EstoqueMed\Core\Bootstrap::init();
use EstoqueMed\Core\{DB,Auth,Audit,Input,HttpException};
use EstoqueMed\Services\{AnalyticsService,DecisionEngine,StockService,StorageGuard,RiskAlertService,ComparisonService,ReportService,PresentationService};

function respond(mixed $data,int $status=200):never {http_response_code($status);header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>true,'data'=>$data],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE|JSON_PRESERVE_ZERO_FRACTION|JSON_PARTIAL_OUTPUT_ON_ERROR);exit;}
function mustPost():void {if($_SERVER['REQUEST_METHOD']!=='POST')throw new HttpException(405,'Utilize POST.');Auth::verifyCsrf();}
function getId(string $key='id'):int {return Input::int($_GET,$key,1);}
function requiredStatus(string $permission='view'):array {return Auth::require($permission);}
function memory(array $v):string {return json_encode($v,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE|JSON_PARTIAL_OUTPUT_ON_ERROR);}
try {
    $route=(string)($_GET['r']??'session');
    if($route==='login') {if($_SERVER['REQUEST_METHOD']!=='POST')throw new HttpException(405,'POST obrigatório');Auth::verifyCsrf();$v=Input::json();respond(['user'=>Auth::login(Input::str($v,'email',190),Input::str($v,'password',200)),'csrf'=>Auth::csrf()]);}
    if($route==='session') { $u=Auth::user(); if($u && time()-(int)($_SESSION['last_active']??0)>1800) {$u=null;Auth::logout();}respond(['user'=>$u,'csrf'=>Auth::csrf(),'permissions'=>['can_stock'=>Auth::can('stock'),'can_buy'=>Auth::can('buy'),'can_catalog'=>Auth::can('catalog'),'can_audit'=>Auth::can('audit'),'can_simulate'=>Auth::can('simulate'),'can_temperature'=>Auth::can('temperature')]]); }
    if($route==='logout'){mustPost();Audit::log('auth.logout','users',(string)(Auth::user()['id']??''));Auth::logout();respond(['logged_out'=>true]);}
    requiredStatus();
    switch($route){
        case 'dashboard':respond(AnalyticsService::dashboard((int)($_GET['days']??30)));
        case 'medications':respond(DB::all('SELECT m.*,COALESCE((SELECT SUM(quantity) FROM batches WHERE medication_id=m.id AND status=\'available\' AND expires_at>=CURDATE()),0) available FROM medications m ORDER BY m.name'));
        case 'medication-save':
            requiredStatus('catalog');mustPost();$v=Input::json();$id=(int)($v['id']??0);
            $data=[Input::str($v,'code',40),Input::str($v,'name',140),Input::str($v,'generic_name',140,false),Input::str($v,'active_ingredient',140,false),Input::str($v,'presentation',120,false),Input::str($v,'concentration',80,false),Input::str($v,'manufacturer',120,false),Input::str($v,'category',90,false),Input::num($v,'temp_min',-30,50),Input::num($v,'temp_max',-30,50),Input::int($v,'min_stock',0,100000),Input::int($v,'safety_stock',0,100000),Input::int($v,'max_stock',0,100000),Input::num($v,'reference_price',0,100000000)];
            if($data[8]>=$data[9]||$data[10]>$data[12])throw new HttpException(422,'Faixa térmica e limite de estoque inválidos.');
            if($id){DB::run('UPDATE medications SET code=?,name=?,generic_name=?,active_ingredient=?,presentation=?,concentration=?,manufacturer=?,category=?,temp_min=?,temp_max=?,min_stock=?,safety_stock=?,max_stock=?,reference_price=? WHERE id=?',[...$data,$id]);}
            else {$id=(int)DB::transaction(static function($p)use($data){$s=$p->prepare('INSERT INTO medications(code,name,generic_name,active_ingredient,presentation,concentration,manufacturer,category,temp_min,temp_max,min_stock,safety_stock,max_stock,reference_price) VALUES('.implode(',',array_fill(0,14,'?')).')');$s->execute($data);return $p->lastInsertId();});}
            Audit::log('catalog.save','medications',(string)$id);respond(['id'=>$id]);
        case 'medication-toggle':
            requiredStatus('catalog');mustPost();$v=Input::json();$id=Input::int($v,'id',1);DB::run('UPDATE medications SET active=IF(active=1,0,1) WHERE id=?',[$id]);Audit::log('catalog.toggle','medications',(string)$id);respond(['id'=>$id]);
        case 'batches':
            $where=isset($_GET['medication_id'])?' WHERE b.medication_id=?':'';$p=isset($_GET['medication_id'])?[(int)$_GET['medication_id']]:[];
            respond(DB::all('SELECT b.*,m.name medication,l.name location,s.name supplier,COALESCE((SELECT SUM(r.quantity) FROM stock_reservations r WHERE r.batch_id=b.id AND r.active=1),0) reserved FROM batches b JOIN medications m ON m.id=b.medication_id JOIN locations l ON l.id=b.location_id LEFT JOIN suppliers s ON s.id=b.supplier_id'.$where.' ORDER BY b.expires_at,b.id',$p));
        case 'batch-create':
            requiredStatus('stock');mustPost();$v=Input::json();$med=Input::int($v,'medication_id',1);$lot=Input::str($v,'lot_number',80);$exp=Input::date(Input::str($v,'expires_at',10));$location=Input::int($v,'location_id',1);$qty=Input::int($v,'quantity',1);$price=Input::num($v,'unit_cost',0);$key=Input::str($v,'event_key',100);
            if($exp<date('Y-m-d'))throw new HttpException(422,'Entrada de lote vencido exige análise, não cadastro automático.');
            $created=DB::transaction(static function($p)use($med,$lot,$exp,$location,$qty,$price,$key){
                $check=$p->prepare('SELECT id,batch_id FROM stock_movements WHERE event_key=?');$check->execute([$key]);
                if($found=$check->fetch())return ['id'=>(int)$found['batch_id'],'duplicate'=>true];
                StorageGuard::ensure($p,$location,$med,$qty);
                $s=$p->prepare('INSERT INTO batches(medication_id,lot_number,expires_at,received_at,initial_quantity,quantity,unit_cost,location_id) VALUES(?,?,?,CURDATE(),?,?,?,?)');
                $s->execute([$med,$lot,$exp,$qty,$qty,$price,$location]);$id=(int)$p->lastInsertId();
                $p->prepare("INSERT INTO stock_movements(event_key,batch_id,medication_id,movement_type,quantity,target_location_id,reason,user_id) VALUES(?,?,?,'entry',?,?,?,?)")->execute([$key,$id,$med,$qty,$location,'Recebimento manual de lote',Auth::user()['id']]);
                return ['id'=>$id,'duplicate'=>false];
            });
            $id=$created['id'];
            if(!$created['duplicate'])Audit::log('batches.create','batches',(string)$id);respond($created);
        case 'locations':respond(DB::all('SELECT l.*,u.name unit_name,d.name device FROM locations l JOIN units u ON u.id=l.unit_id LEFT JOIN devices d ON d.id=l.device_id ORDER BY l.id'));
        case 'movements':respond(DB::all('SELECT x.*,m.name medication,b.lot_number,u.name user_name FROM stock_movements x JOIN medications m ON m.id=x.medication_id JOIN batches b ON b.id=x.batch_id LEFT JOIN users u ON u.id=x.user_id ORDER BY x.id DESC LIMIT 250'));
        case 'move':requiredStatus('stock');mustPost();respond(StockService::move(Input::json()));
        case 'transfer':requiredStatus('stock');mustPost();respond(StockService::transfer(Input::json()));
        case 'reverse':requiredStatus('stock');mustPost();respond(StockService::reverse(Input::json()));
        case 'fefo':respond(StockService::fefo(getId('medication_id'),(int)($_GET['quantity']??1)));
        case 'history':respond(AnalyticsService::history(getId('medication_id')));
        case 'forecast':respond(AnalyticsService::forecast(getId('medication_id'),(int)($_GET['days']??30)));
        case 'replenishment':respond(DecisionEngine::recommendation(getId('medication_id')));
        case 'all-replenishment':
            $rows=DB::all('SELECT id,name FROM medications WHERE active=1 ORDER BY name');$out=[];foreach($rows as $m){$r=DecisionEngine::recommendation((int)$m['id']);if($r['needed']>0)$out[]=['id'=>$m['id'],'name'=>$m['name'],'quantity'=>$r['quantity'],'needed'=>$r['needed'],'priority'=>$r['priority'],'supplier'=>$r['supplier']['supplier']??'Sem oferta viável','cost'=>$r['estimated_cost'],'coverage'=>$r['coverage_days'],'feasible'=>$r['feasible']];}respond($out);
        case 'recommendation-save':
            requiredStatus('buy');mustPost();$v=Input::json();$r=DecisionEngine::recommendation(Input::int($v,'medication_id',1));if(!$r['quantity']||!$r['supplier'])throw new HttpException(422,'Não há recomendação de compra viável.');
            DB::run('INSERT INTO purchase_recommendations(medication_id,supplier_id,quantity,estimated_cost,priority,explanation,details_json,created_by) VALUES(?,?,?,?,?,?,?,?)',[$r['medication']['id'],$r['supplier']['supplier_id'],$r['quantity'],$r['estimated_cost'],$r['priority'],$r['explanation'],memory($r),Auth::user()['id']]);$id=(int)DB::get()->lastInsertId();Audit::log('recommendation.create','purchase_recommendations',(string)$id);respond(['id'=>$id]);
        case 'recommendations':respond(DB::all('SELECT r.*,m.name medication,s.name supplier FROM purchase_recommendations r JOIN medications m ON m.id=r.medication_id LEFT JOIN suppliers s ON s.id=r.supplier_id ORDER BY r.id DESC LIMIT 200'));
        case 'recommendation-review':
            requiredStatus('buy');mustPost();$v=Input::json();$id=Input::int($v,'id',1);$status=Input::str($v,'status',16);if(!in_array($status,['approved','rejected'],true))throw new HttpException(422,'Status inválido.');
            $affected=DB::run("UPDATE purchase_recommendations SET status=?,reviewed_by=?,reviewed_at=NOW() WHERE id=? AND status='suggested'",[$status,Auth::user()['id'],$id]);if(!$affected)throw new HttpException(409,'Recomendação não está pendente.');Audit::log('recommendation.'.$status,'purchase_recommendations',(string)$id);respond(['id'=>$id,'status'=>$status]);
        case 'orders':respond(DB::all('SELECT o.*,s.name supplier,m.name medication,i.id item_id,i.quantity,i.received_quantity,i.unit_price FROM purchase_orders o JOIN suppliers s ON s.id=o.supplier_id JOIN purchase_order_items i ON i.order_id=o.id JOIN medications m ON m.id=i.medication_id ORDER BY o.id DESC'));
        case 'order-create':
            requiredStatus('buy');mustPost();$v=Input::json();$id=Input::int($v,'recommendation_id',1);
            $orderId=DB::transaction(static function($p)use($id){$s=$p->prepare('SELECT r.*,sp.lead_days,sp.unit_price FROM purchase_recommendations r JOIN supplier_products sp ON sp.supplier_id=r.supplier_id AND sp.medication_id=r.medication_id WHERE r.id=? FOR UPDATE');$s->execute([$id]);$r=$s->fetch();if(!$r||$r['status']!=='approved')throw new HttpException(409,'Recomendação não aprovada ou já convertida.');$p->prepare("INSERT INTO purchase_orders(recommendation_id,supplier_id,expected_at,created_by) VALUES(?,?,DATE_ADD(CURDATE(),INTERVAL ? DAY),?)")->execute([$id,$r['supplier_id'],$r['lead_days'],Auth::user()['id']]);$orderId=(int)$p->lastInsertId();$p->prepare('INSERT INTO purchase_order_items(order_id,medication_id,quantity,unit_price) VALUES(?,?,?,?)')->execute([$orderId,$r['medication_id'],$r['quantity'],$r['unit_price']]);$p->prepare("UPDATE purchase_recommendations SET status='ordered' WHERE id=?")->execute([$id]);return $orderId;});Audit::log('purchase.create','purchase_orders',(string)$orderId);respond(['id'=>$orderId]);
        case 'order-receive':
            requiredStatus('stock');mustPost();$v=Input::json();$item=Input::int($v,'item_id',1);$quantity=Input::int($v,'quantity',1);$lot=Input::str($v,'lot_number',80);$exp=Input::date(Input::str($v,'expires_at',10));$loc=Input::int($v,'location_id',1);$key=Input::str($v,'event_key',100);
            if($exp<date('Y-m-d'))throw new HttpException(422,'Lote vencido exige quarentena e análise antes do recebimento.');
            $result=DB::transaction(static function($p)use($item,$quantity,$lot,$exp,$loc,$key){
                $s=$p->prepare('SELECT r.id FROM receipts r WHERE event_key=?');$s->execute([$key]);if($found=$s->fetch())return ['receipt_id'=>(int)$found['id'],'duplicate'=>true];
                $s=$p->prepare('SELECT i.*,o.status,o.supplier_id FROM purchase_order_items i JOIN purchase_orders o ON o.id=i.order_id WHERE i.id=? FOR UPDATE');$s->execute([$item]);$i=$s->fetch();if(!$i||!in_array($i['status'],['issued','partially_received'],true))throw new HttpException(409,'Pedido não apto a receber.');
                if($i['received_quantity']+$quantity>$i['quantity'])throw new HttpException(422,'Quantidade acima do saldo do pedido.');
                StorageGuard::ensure($p,$loc,(int)$i['medication_id'],$quantity);
                $s=$p->prepare('SELECT * FROM batches WHERE medication_id=? AND lot_number=? FOR UPDATE');$s->execute([$i['medication_id'],$lot]);$b=$s->fetch();
                if($b){if($b['expires_at']!==$exp||$b['location_id']!=$loc||!in_array($b['status'],['available','depleted'],true))throw new HttpException(409,'Lote incompatível ou indisponível.');$batchId=(int)$b['id'];$p->prepare("UPDATE batches SET quantity=quantity+?,initial_quantity=initial_quantity+?,status='available' WHERE id=?")->execute([$quantity,$quantity,$batchId]);}
                else{$p->prepare('INSERT INTO batches(medication_id,lot_number,expires_at,received_at,initial_quantity,quantity,unit_cost,supplier_id,location_id) VALUES(?,?,?,CURDATE(),?,?,?,?,?)')->execute([$i['medication_id'],$lot,$exp,$quantity,$quantity,$i['unit_price'],$i['supplier_id'],$loc]);$batchId=(int)$p->lastInsertId();}
                $p->prepare('UPDATE purchase_order_items SET received_quantity=received_quantity+? WHERE id=?')->execute([$quantity,$item]);
                $p->prepare('INSERT INTO receipts(event_key,order_item_id,batch_id,quantity,received_by) VALUES(?,?,?,?,?)')->execute([$key,$item,$batchId,$quantity,Auth::user()['id']]);$rid=(int)$p->lastInsertId();
                $p->prepare("INSERT INTO stock_movements(event_key,batch_id,medication_id,movement_type,quantity,target_location_id,reason,user_id,related_entity,related_id) VALUES(?,?,?,'entry',?,?,?,?,'receipt',?)")->execute(['receipt-movement-'.$key,$batchId,$i['medication_id'],$quantity,$loc,'Recebimento de pedido',Auth::user()['id'],$rid]);
                $s=$p->prepare('SELECT SUM(quantity-received_quantity) AS missing FROM purchase_order_items WHERE order_id=?');$s->execute([$i['order_id']]);$missing=(int)$s->fetchColumn();
                $p->prepare('UPDATE purchase_orders SET status=? WHERE id=?')->execute([$missing===0?'received':'partially_received',$i['order_id']]);return ['receipt_id'=>$rid,'batch_id'=>$batchId,'duplicate'=>false];
            });if(!$result['duplicate'])Audit::log('purchase.receive','purchase_order_items',(string)$item,['quantity'=>$quantity]);respond($result);
        case 'suppliers':respond(DB::all('SELECT * FROM suppliers ORDER BY name'));
        case 'offers':respond(DB::all('SELECT sp.*,s.name supplier,m.name medication FROM supplier_products sp JOIN suppliers s ON s.id=sp.supplier_id JOIN medications m ON m.id=sp.medication_id ORDER BY sp.medication_id,sp.unit_price'));
        case 'supplier-save':
            requiredStatus('buy');mustPost();$v=Input::json();DB::run('INSERT INTO suppliers(name,identifier,contact,reliability) VALUES(?,?,?,?)',[Input::str($v,'name',150),Input::str($v,'identifier',60),Input::str($v,'contact',160,false),Input::num($v,'reliability',0,1)]);$newId=(int)DB::get()->lastInsertId();Audit::log('supplier.create','suppliers',(string)$newId);respond(['id'=>$newId]);
        case 'offer-save':
            requiredStatus('buy');mustPost();$v=Input::json();DB::run('INSERT INTO supplier_products(supplier_id,medication_id,unit_price,lead_days,lead_min_days,lead_max_days,min_order,pack_multiple,freight) VALUES(?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE unit_price=VALUES(unit_price),lead_days=VALUES(lead_days),min_order=VALUES(min_order),pack_multiple=VALUES(pack_multiple),freight=VALUES(freight)',[Input::int($v,'supplier_id',1),Input::int($v,'medication_id',1),Input::num($v,'unit_price',0),Input::int($v,'lead_days',1,365),Input::int($v,'lead_days',1,365),Input::int($v,'lead_days',1,365),Input::int($v,'min_order',1),Input::int($v,'pack_multiple',1),Input::num($v,'freight',0)]);Audit::log('supplier.offer','supplier_products',(string)$v['supplier_id'].'/'.(string)$v['medication_id']);respond(['saved'=>true]);
        case 'scenario':
            requiredStatus('simulate');mustPost();$v=Input::json();$med=Input::int($v,'medication_id',1);
            $allowed=['horizon','daily','growth_pct','safety_stock','capacity','budget','lead_days','unit_price','temperature_fault','validity_days','lead_variation','purchase_frequency','unavailable_pct'];$opts=[];
            foreach($allowed as $k)if(array_key_exists($k,$v)){$opts[$k]=$k==='temperature_fault'?(bool)$v[$k]:Input::num($v,$k,$k==='growth_pct'?-90:0,($k==='growth_pct'?500:100000000));}
            $r=DecisionEngine::scenario($med,$opts);DB::run("INSERT INTO analytics_runs(medication_id,kind,inputs_json,results_json,created_by) VALUES(?,'scenario',?,?,?)",[$med,memory($opts),memory($r),Auth::user()['id']]);respond($r);
        case 'compare':requiredStatus('simulate');mustPost();$v=Input::json();$med=Input::int($v,'medication_id',1);$days=Input::int($v,'days',30,90);$r=ComparisonService::compare($med,$days);DB::run("INSERT INTO analytics_runs(medication_id,kind,inputs_json,results_json,created_by) VALUES(?,'comparison',?,?,?)",[$med,memory(['days'=>$days]),memory($r),Auth::user()['id']]);respond($r);
        case 'devices':respond(DB::all('SELECT d.*,u.name unit_name FROM devices d JOIN units u ON u.id=d.unit_id ORDER BY d.id'));
        case 'readings':respond(DB::all('SELECT t.* FROM temperature_readings t WHERE t.device_id=? ORDER BY t.recorded_at DESC LIMIT 100',[(int)($_GET['device_id']??1)]));
        case 'device-event':requiredStatus('temperature');mustPost();respond(StockService::temperatureEvent(Input::json()));
        case 'incidents':respond(DB::all('SELECT t.*,d.name device FROM temperature_incidents t JOIN devices d ON d.id=t.device_id ORDER BY t.id DESC LIMIT 100'));
        case 'incident-resolve':requiredStatus('temperature');mustPost();$v=Input::json();$id=Input::int($v,'id',1);$updated=DB::run("UPDATE temperature_incidents SET status='resolved',resolved_at=NOW() WHERE id=? AND status='open'",[$id]);Audit::log('temperature.resolved','temperature_incidents',(string)$id,['note'=>'A resolução não libera automaticamente os lotes']);respond(['changed'=>$updated]);
        case 'alerts':RiskAlertService::refresh();respond(DB::all('SELECT * FROM alerts ORDER BY FIELD(status,\'open\',\'resolved\'),FIELD(level,\'critical\',\'warning\',\'info\'),id DESC LIMIT 200'));
        case 'alert-resolve':mustPost();$v=Input::json();$id=Input::int($v,'id',1);$mode=Input::str($v,'mode',20);if(!in_array($mode,['read','resolve'],true))throw new HttpException(422,'Ação inválida');if($mode==='read')DB::run('UPDATE alerts SET is_read=1 WHERE id=?',[$id]);else DB::run("UPDATE alerts SET status='resolved',resolved_by=? WHERE id=?",[Auth::user()['id'],$id]);Audit::log('alerts.'.$mode,'alerts',(string)$id);respond(['id'=>$id,'mode'=>$mode]);
        case 'audit':requiredStatus('audit');respond(DB::all('SELECT a.*,u.name user_name FROM audit_logs a LEFT JOIN users u ON a.user_id=u.id ORDER BY a.id DESC LIMIT 400'));
        case 'presentation-summary':
            requiredStatus('report');
            $report=PresentationService::data(getId('medication_id'),Input::int($_GET,'horizon',7,90),Input::int($_GET,'comparison_days',30,90));
            respond(['medication'=>$report['medication'],'available'=>$report['recommendation']['stock']['available'],'projected'=>$report['forecast']['total'],'suggested'=>$report['recommendation']['quantity'],'estimated_cost'=>$report['recommendation']['estimated_cost']]);
        case 'presentation-pptx':
            requiredStatus('report');
            if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET')throw new HttpException(405,'Utilize GET.');
            $report=PresentationService::data(getId('medication_id'),Input::int($_GET,'horizon',7,90),Input::int($_GET,'comparison_days',30,90));
            $file=PresentationService::render($report);
            if(strlen($file)<1500)throw new \RuntimeException('Arquivo não foi gerado corretamente.');
            header('Content-Type: application/vnd.openxmlformats-officedocument.presentationml.presentation');
            header('Content-Disposition: attachment; filename="EstoqueMed_Mb_Apresentacao_'.date('Ymd_His').'.pptx"');
            header('Content-Length: '.strlen($file));
            header('Cache-Control: private, no-store, max-age=0');
            echo $file;exit;
        case 'report':requiredStatus('report');$type=(string)($_GET['type']??'stock');$format=(string)($_GET['format']??'json');if($format==='csv'){ReportService::csv($type);exit;}if($format==='pdf'){ReportService::pdf($type);exit;}respond(ReportService::data($type));
        case 'user-list':requiredStatus('admin');respond(DB::all('SELECT id,name,email,role,active,last_login FROM users ORDER BY id'));
        case 'user-create':requiredStatus('admin');mustPost();$v=Input::json();$role=Input::str($v,'role',20);if(!in_array($role,['admin','purchaser','pharmacist','auditor','viewer'],true))throw new HttpException(422,'Perfil inválido');$password=Input::str($v,'password',200);if(strlen($password)<12)throw new HttpException(422,'Senha com no mínimo 12 caracteres.');if(!filter_var((string)($v['email']??''),FILTER_VALIDATE_EMAIL))throw new HttpException(422,'E-mail inválido.');DB::run('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)',[Input::str($v,'name',120),strtolower(Input::str($v,'email',190)),password_hash($password,PASSWORD_DEFAULT),$role]);Audit::log('user.create','users',(string)DB::get()->lastInsertId());respond(['created'=>true]);
        case 'password-change':mustPost();$v=Input::json();$user=Auth::user();$hash=DB::scalar('SELECT password_hash FROM users WHERE id=?',[$user['id']]);if(!password_verify(Input::str($v,'old_password',200),$hash))throw new HttpException(401,'Senha atual incorreta.');$new=Input::str($v,'new_password',200);if(strlen($new)<12)throw new HttpException(422,'Senha nova deve conter no mínimo 12 caracteres.');DB::run('UPDATE users SET password_hash=? WHERE id=?',[password_hash($new,PASSWORD_DEFAULT),$user['id']]);Audit::log('auth.password','users',(string)$user['id']);respond(['changed'=>true]);
        default:throw new HttpException(404,'Rota inexistente.');
    }
} catch(HttpException $e) {
    http_response_code($e->status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
} catch(\Throwable $e) {
    $id = date('YmdHis').'-'.bin2hex(random_bytes(3));
    $route = substr(preg_replace('/[^a-z0-9_-]/i', '', (string)($_GET['r']??'session')), 0, 60);
    $details = sprintf("[%s] %s [%s] %s em %s:%d\n", date('c'), $id, $route, $e->getMessage(), $e->getFile(), $e->getLine());
    $log = dirname(__DIR__).'/storage/logs/erros_api.log';
    if (is_dir(dirname($log)) && is_writable(dirname($log))) file_put_contents($log, $details, FILE_APPEND | LOCK_EX);
    else error_log($details);
    $http = 500;
    $error = 'Não foi possível concluir esta operação. Consulte o diagnóstico pelo código exibido.';
    if ($e instanceof \PDOException) {
        $code = (string)$e->getCode();
        $driver = (int)($e->errorInfo[1]??0);
        if (in_array($driver, [1045, 1698], true)) {
            $http = 503;
            $error = 'O acesso ao banco foi recusado. Confira usuário e senha da conexão.';
        } elseif (in_array($driver, [1049, 2002, 2003, 2006, 2013], true) || $code==='08006') {
            $http = 503;
            $error = 'Não foi possível conectar ao MySQL/MariaDB. Confira o serviço e o banco configurado.';
        } elseif (in_array($driver, [1054, 1146], true) || in_array($code, ['42S02', '42S22'], true)) {
            $error = 'A estrutura do banco está incompleta ou desatualizada. Execute ATUALIZAR_BANCO.bat.';
        } elseif ($driver === 1062 || $code === '23000') {
            $http = 409;
            $error = 'Já existe um registro com essas informações ou há uma referência inválida.';
        } else {
            $error = 'Falha na consulta do banco. Execute DIAGNOSTICAR.bat e consulte os registros técnicos.';
        }
    } elseif ($e instanceof \RuntimeException && str_contains($e->getMessage(), 'Conexão não configurada')) {
        $http = 503;
        $error = 'A conexão do banco ainda não foi configurada. Execute INSTALAR.bat.';
    } elseif ($e instanceof \RuntimeException && str_contains($e->getMessage(), 'pdo_mysql')) {
        $http = 503;
        $error = 'A extensão pdo_mysql não está habilitada no PHP utilizado pelo servidor.';
    }
    http_response_code($http);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode(['ok'=>false,'error'=>$error,'reference'=>$id], JSON_UNESCAPED_UNICODE);
}
