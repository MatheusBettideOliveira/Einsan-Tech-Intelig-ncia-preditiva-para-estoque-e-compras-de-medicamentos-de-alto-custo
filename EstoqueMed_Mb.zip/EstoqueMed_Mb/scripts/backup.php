<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/Core/Bootstrap.php';
\EstoqueMed\Core\Bootstrap::init(false);
use EstoqueMed\Core\DB;
if(PHP_SAPI!=='cli')exit('CLI only');
if(!is_file(dirname(__DIR__).'/.env')){fwrite(STDERR,"Execute INSTALAR.bat primeiro.\n");exit(1);}
try{
 $db=DB::get();$dir=dirname(__DIR__).'/storage/backups';if(!is_dir($dir))mkdir($dir,0700,true);
 $filename=$dir.'/estoquemed_'.date('Ymd_His').'.sql.gz';$sql="-- EstoqueMed_Mb BACKUP ".date(DATE_ATOM)."\nSET FOREIGN_KEY_CHECKS=0;\n";
 $tables=$db->query('SHOW FULL TABLES WHERE Table_type = \'BASE TABLE\'')->fetchAll(PDO::FETCH_NUM);
 foreach($tables as $info){$name=$info[0];$safe='`'.str_replace('`','``',$name).'`';
  $create=$db->query('SHOW CREATE TABLE '.$safe)->fetch(PDO::FETCH_NUM);
  $sql.="\nDROP TABLE IF EXISTS ".$safe.";\n".$create[1].";\n";
  $rows=$db->query('SELECT * FROM '.$safe);
  while($row=$rows->fetch(PDO::FETCH_ASSOC)){
   $columns=implode(',',array_map(static fn($s)=>'`'.str_replace('`','``',$s).'`',array_keys($row)));
   $values=implode(',',array_map(static fn($v)=>$v===null?'NULL':$db->quote((string)$v),array_values($row)));
   $sql.="INSERT INTO $safe ($columns) VALUES ($values);\n";
  }
 }
 $sql.="SET FOREIGN_KEY_CHECKS=1;\n";
 if(file_put_contents($filename,gzencode($sql,7),LOCK_EX)===false)throw new RuntimeException('Não foi possível gravar o backup.');
 if(DIRECTORY_SEPARATOR==='/')chmod($filename,0600);
 $config=dirname(__DIR__).'/.env';$copy=$dir.'/env_'.date('Ymd_His').'.conf';copy($config,$copy);if(DIRECTORY_SEPARATOR==='/')chmod($copy,0600);
  
 $existing=glob($dir.'/estoquemed_*.sql.gz');rsort($existing);
 foreach(array_slice($existing,7) as $old){$stamp=substr(basename($old),9,15);@unlink($old);@unlink($dir.'/env_'.$stamp.'.conf');}
 echo 'Backup gerado: '.$filename."\n".'Inclui dados sensíveis: proteger acesso à pasta e cópias externas.' ."\n";
} catch(Throwable $e){fwrite(STDERR,'Falha: '.$e->getMessage()."\n");exit(1);}
