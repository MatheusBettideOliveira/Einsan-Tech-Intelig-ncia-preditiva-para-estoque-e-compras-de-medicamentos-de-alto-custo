<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') exit(1);
require dirname(__DIR__).'/app/Core/Bootstrap.php';
\EstoqueMed\Core\Bootstrap::init(false);
function perguntar(string $titulo, string $padrao=''): string {
    echo $titulo.($padrao!==''?' ['.$padrao.']':'').': ';
    $entrada = fgets(STDIN);
    if ($entrada === false) throw new RuntimeException('Entrada cancelada.');
    $entrada=trim($entrada);
    return $entrada===''?$padrao:$entrada;
}
try {
    if (!extension_loaded('pdo_mysql')) throw new RuntimeException('Extensão pdo_mysql não habilitada neste PHP.');
    $base=dirname(__DIR__);
    $env=$base.'/.env';
    echo "ESTOQUEMED_MB - CORRIGIR CONEXAO AO BANCO\n";
    echo "Nenhuma tabela ou registro será excluído.\n";
    $host=perguntar('Servidor',getenv('DB_HOST')?:'127.0.0.1');
    $port=perguntar('Porta',getenv('DB_PORT')?:'3306');
    $name=perguntar('Banco de dados',getenv('DB_NAME')?:'estoquemed_mb');
    $user=perguntar('Usuário do banco',getenv('DB_USER')?:'root');
    echo 'Senha (digitacao visivel; ENTER mantém a senha atual; digite - para limpar): ';
    $pass=fgets(STDIN);
    if ($pass===false) throw new RuntimeException('Entrada cancelada.');
    $pass=rtrim($pass,"\r\n");
    if ($pass==='') $pass=getenv('DB_PASSWORD')?:'';
    if ($pass==='-') $pass='';
    if (!preg_match('/^[a-zA-Z0-9_]+$/',$name) || !ctype_digit($port) || (int)$port<1 || (int)$port>65535) throw new RuntimeException('Banco ou porta inválidos.');
    $pdo=new PDO("mysql:host=$host;port=$port;dbname=$name;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_TIMEOUT=>6]);
    $schema=$pdo->query("SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name IN ('users','medications','batches')")->fetchAll(PDO::FETCH_COLUMN);
    if (count($schema)!==3) throw new RuntimeException('Este banco não contém a estrutura básica do EstoqueMed_Mb. Verifique o nome informado.');
    $values=['APP_TIMEZONE'=>getenv('APP_TIMEZONE')?:'America/Sao_Paulo','DB_HOST'=>$host,'DB_PORT'=>$port,'DB_NAME'=>$name,'DB_USER'=>$user,'DB_PASSWORD'=>$pass];
    $linhas=is_file($env)?file($env,FILE_IGNORE_NEW_LINES):[];
    $feitos=[];
    $saida=[];
    $encode=static fn(string $v):string=>'"'.str_replace(['\\','"',"\n","\r"],['\\\\','\\"','',''],$v).'"';
    foreach ($linhas as $line) {
        if (preg_match('/^\s*([A-Z][A-Z0-9_]*)\s*=/', $line, $match) && array_key_exists($match[1],$values)) {
            if (!isset($feitos[$match[1]])) $saida[]=$match[1].'='.$encode((string)$values[$match[1]]);
            $feitos[$match[1]]=true;
        } else $saida[]=$line;
    }
    foreach ($values as $key=>$value) if (!isset($feitos[$key])) $saida[]=$key.'='.$encode((string)$value);
    if (is_file($env)) {
        $pasta=$base.'/storage/backups';
        if (!is_dir($pasta) && !mkdir($pasta,0700,true)) throw new RuntimeException('Não foi possível proteger a configuração anterior.');
        $backup=$pasta.'/configuracao-'.date('Ymd-His').'-'.bin2hex(random_bytes(3)).'.bak';
        if (!copy($env,$backup)) throw new RuntimeException('Falha ao preservar a configuração anterior.');
        if (DIRECTORY_SEPARATOR==='/') chmod($backup,0600);
    }
    if (file_put_contents($env,implode("\n",$saida)."\n",LOCK_EX)===false) throw new RuntimeException('Não foi possível atualizar a configuração.');
    if (DIRECTORY_SEPARATOR==='/') chmod($env,0600);
    echo "\n[OK] Conexão confirmada e configuração atualizada.\n";
    echo "Execute ATUALIZAR_BANCO.bat para revisar a estrutura, ou DIAGNOSTICAR.bat para testar as telas.\n";
} catch (Throwable $e) {
    fwrite(STDERR,"[FALHA] ".$e->getMessage()."\n");
    exit(1);
}
