<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/Core/Bootstrap.php';
\EstoqueMed\Core\Bootstrap::init(false);
use EstoqueMed\Core\DB;
if(!extension_loaded('pdo_mysql')||!is_file(dirname(__DIR__).'/.env')){echo "[SKIP] Integração MySQL: extensão/instalação ausente.\n";exit(2);}
try{
 $pdo=DB::get();$tables=['users','medications','batches','stock_movements','consumption_history','purchase_orders','audit_logs','temperature_readings'];
 foreach($tables as $table){$c=(int)$pdo->query('SELECT COUNT(*) FROM `'.$table.'`')->fetchColumn();echo "[OK] $table: $c registros\n";}
 $count=(int)$pdo->query('SELECT COUNT(*) FROM batches WHERE quantity<0')->fetchColumn();if($count)throw new RuntimeException('Lotes com quantidade negativa');
 $count=(int)$pdo->query("SELECT COUNT(*) FROM batches WHERE status='available' AND expires_at<CURDATE()")->fetchColumn();echo '[CHECK] Lotes vencidos ainda marcados disponíveis: '.$count.' (FEFO os exclui por data)' ."\n";
 $pass=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE LENGTH(password_hash)<50")->fetchColumn();if($pass)throw new RuntimeException('Hashes de senhas possivelmente inválidos.');
 echo "[OK] Leitura de banco, integridade básica e formatos de hash.\n";
}catch(Throwable $e){fwrite(STDERR,'[FAIL] '.$e->getMessage()."\n");exit(1);}
