<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') exit(1);
require dirname(__DIR__).'/app/Core/Bootstrap.php';
\EstoqueMed\Core\Bootstrap::init(false);
use EstoqueMed\Core\DB;
use EstoqueMed\Services\{AnalyticsService,DecisionEngine,ComparisonService,ReportService,StockService};

$raiz = dirname(__DIR__);
$falhas = 0;
$sucessos = 0;
function verificar(string $nome, callable $fn): void {
    global $falhas, $sucessos;
    try {
        $fn();
        $sucessos++;
        echo '[OK] '.$nome."\n";
    } catch (Throwable $e) {
        $falhas++;
        echo '[FALHOU] '.$nome.': '.$e->getMessage()."\n";
    }
}
echo "ESTOQUEMED_MB - VERIFICACAO DE INSTALACAO\n".date('d/m/Y H:i:s')."\n";
echo 'PHP: '.PHP_VERSION."\n";
if (!extension_loaded('pdo_mysql')) {
    echo "[FALHOU] Extensao pdo_mysql ausente. Ative no PHP utilizado pelo sistema.\n";
    exit(1);
}
if (!is_file($raiz.'/.env')) {
    echo "[FALHOU] Configuracao .env ausente. Execute INSTALAR.bat.\n";
    exit(1);
}
try {
    $db=DB::get();
    echo '[OK] Conexão com o banco '.(getenv('DB_NAME') ?: 'não informado')."\n";
    echo '[OK] MySQL/MariaDB '.(string)$db->query('SELECT VERSION()')->fetchColumn()."\n";
} catch (Throwable $e) {
    echo '[FALHOU] Conexão: '.$e->getMessage()."\n";
    exit(1);
}
$schema = file_get_contents($raiz.'/database/schema.sql');
if ($schema === false) {echo "[FALHOU] Arquivo de estrutura do banco ausente.\n"; exit(1);}
preg_match_all('/CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+`?([a-z_][a-z0-9_]*)`?/i', $schema, $tabelas);
foreach ($tabelas[1] as $nome) {
    verificar('Estrutura: '.$nome, static function() use($nome): void {
        $db=DB::get();
        $s=$db->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');
        $s->execute([$nome]);
        if (!(int)$s->fetchColumn()) throw new RuntimeException('tabela ausente');
    });
}
if ($falhas) {
    echo "A estrutura está incompleta. Execute ATUALIZAR_BANCO.bat antes de tentar novamente.\n";
    exit(1);
}
$rotas = [
    'Visão geral' => static fn()=>AnalyticsService::dashboard(30),
    'Medicamentos' => static fn()=>DB::all('SELECT id,name FROM medications ORDER BY name LIMIT 3'),
    'Lotes e validades' => static fn()=>DB::all('SELECT b.id,m.name FROM batches b JOIN medications m ON m.id=b.medication_id LIMIT 3'),
    'Movimentações' => static fn()=>DB::all('SELECT id FROM stock_movements ORDER BY id DESC LIMIT 3'),
    'Locais de armazenamento' => static fn()=>DB::all('SELECT l.id,u.name FROM locations l JOIN units u ON u.id=l.unit_id LIMIT 3'),
    'Cofres refrigerados' => static fn()=>DB::all('SELECT d.id,u.name FROM devices d JOIN units u ON u.id=d.unit_id LIMIT 3'),
    'Ocorrências de conservação' => static fn()=>DB::all('SELECT id FROM temperature_incidents LIMIT 3'),
    'Fornecedores' => static fn()=>DB::all('SELECT id,name FROM suppliers LIMIT 3'),
    'Condições de fornecimento' => static fn()=>DB::all('SELECT sp.id,m.name FROM supplier_products sp JOIN medications m ON m.id=sp.medication_id LIMIT 3'),
    'Compras registradas' => static fn()=>DB::all('SELECT id FROM purchase_orders LIMIT 3'),
    'Sugestões registradas' => static fn()=>DB::all('SELECT id FROM purchase_recommendations LIMIT 3'),
    'Alertas' => static fn()=>DB::all('SELECT id FROM alerts ORDER BY id DESC LIMIT 3'),
    'Histórico de atividades' => static fn()=>DB::all('SELECT id FROM audit_logs ORDER BY id DESC LIMIT 3'),
    'Usuários' => static fn()=>DB::all('SELECT id,role FROM users LIMIT 3'),
];
foreach (['stock','movements','expiry','suppliers','orders','audits','consumption','temperature'] as $tipo) {
    $rotas['Relatório: '.$tipo] = static fn()=>ReportService::data($tipo);
}
$primeiro=(int)DB::scalar('SELECT COALESCE(MIN(id),0) FROM medications WHERE active=1');
if ($primeiro) {
    $rotas['Previsão de consumo'] = static fn()=>AnalyticsService::forecast($primeiro,30);
    $rotas['Recomendação de reposição'] = static fn()=>DecisionEngine::recommendation($primeiro);
    $rotas['Alocação por validade'] = static fn()=>StockService::fefo($primeiro,1);
    $temHistorico=(int)DB::scalar('SELECT COUNT(*) FROM consumption_history WHERE medication_id=?',[$primeiro]);
    $temOfertas=(int)DB::scalar('SELECT COUNT(*) FROM supplier_products WHERE medication_id=?',[$primeiro]);
    if ($temHistorico && $temOfertas) $rotas['Comparação de estratégias'] = static fn()=>ComparisonService::compare($primeiro,60);
}
foreach ($rotas as $nome=>$fn) verificar($nome,$fn);
$conta = (int)DB::scalar('SELECT COUNT(*) FROM users WHERE active=1');
if ($conta === 0) echo "[ATENCAO] Nenhum usuário ativo cadastrado. A carga inicial pode não ter sido concluída.\n";
echo "\nResultado: $sucessos verificações aprovadas; $falhas falha(s).\n";
exit($falhas ? 1 : 0);
