<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') exit(1);
require dirname(__DIR__).'/app/Core/Bootstrap.php';
\EstoqueMed\Core\Bootstrap::init(false);
use EstoqueMed\Core\DB;

function partesColunas(string $sql): array {
    $inicio = strpos($sql, '(');
    if ($inicio === false) return [];
    $depth = 0;
    $fragmento = '';
    $partes = [];
    $n = strlen($sql);
    for ($i=$inicio+1; $i<$n; $i++) {
        $c = $sql[$i];
        if ($c === '(') $depth++;
        if ($c === ')') {
            if ($depth === 0) break;
            $depth--;
        }
        if ($c === ',' && $depth === 0) {
            $partes[] = trim($fragmento);
            $fragmento = '';
            continue;
        }
        $fragmento .= $c;
    }
    if (trim($fragmento) !== '') $partes[] = trim($fragmento);
    $colunas = [];
    foreach ($partes as $parte) {
        if (preg_match('/^`?([a-z_][a-z0-9_]*)`?\s+(?:TINYINT|SMALLINT|INT|BIGINT|CHAR|VARCHAR|DECIMAL|TEXT|LONGTEXT|DATE|DATETIME|TIMESTAMP|ENUM)\b/i', $parte, $match)) {
            $colunas[$match[1]] = $parte;
        }
    }
    return $colunas;
}

try {
    $raiz = dirname(__DIR__);
    if (!is_file($raiz.'/.env')) throw new RuntimeException('Configuração de conexão (.env) não encontrada. Execute INSTALAR.bat para configurar a aplicação.');
    $pdo = DB::get();
    $schema = file_get_contents($raiz.'/database/schema.sql');
    if ($schema === false) throw new RuntimeException('Estrutura database/schema.sql não encontrada.');
    preg_match_all('/CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+`?[a-z_][a-z0-9_]*`?\s*\(.*?\)\s*;/is', $schema, $comandos);
    if (!$comandos[0]) throw new RuntimeException('Nenhuma definição de tabela válida foi encontrada.');
    $criadas = [];
    $corrigidas = [];
    $pendencias = [];
    $existentes = $pdo->query('SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type=\'BASE TABLE\'')->fetchAll(PDO::FETCH_COLUMN);
    foreach ($comandos[0] as $sql) {
        if (!preg_match('/^CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+`?([a-z_][a-z0-9_]*)`?/i', $sql, $m)) continue;
        $tabela = $m[1];
        if (!in_array($tabela, $existentes, true)) {
            $pdo->exec($sql);
            $criadas[] = $tabela;
            echo '[CRIADA] '.$tabela."\n";
        }
        $tem = $pdo->prepare('SELECT column_name FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=?');
        $tem->execute([$tabela]);
        $colunas = $tem->fetchAll(PDO::FETCH_COLUMN);
        foreach (partesColunas($sql) as $nome=>$definicao) {
            if (in_array($nome, $colunas, true)) continue;
            $segura = !preg_match('/\b(PRIMARY\s+KEY|UNIQUE|AUTO_INCREMENT)\b/i', $definicao)
                && (preg_match('/\bDEFAULT\b/i', $definicao) || (preg_match('/\bNULL\b/i', $definicao) && !preg_match('/\bNOT\s+NULL\b/i', $definicao)));
            if (!$segura) {
                $pendencias[] = $tabela.'.'.$nome;
                continue;
            }
            try {
                $pdo->exec('ALTER TABLE `'.$tabela.'` ADD COLUMN '.$definicao);
                $corrigidas[] = $tabela.'.'.$nome;
                echo '[CORRIGIDA] '.$tabela.'.'.$nome."\n";
            } catch (Throwable $e) {
                $pendencias[] = $tabela.'.'.$nome;
                error_log('EstoqueMed_Mb: não foi possível corrigir '.$tabela.'.'.$nome.': '.$e->getMessage());
            }
        }
    }
    echo "\nTabelas criadas: ".count($criadas)."; campos corrigidos: ".count($corrigidas).".\n";
    if ($pendencias) {
        echo 'Dependem de avaliação técnica: '.implode(', ', $pendencias)."\n";
        exit(2);
    }
    echo "Atualização de estrutura concluída sem exclusão de registros.\n";
} catch (Throwable $e) {
    fwrite(STDERR, 'FALHA AO ATUALIZAR: '.$e->getMessage()."\n");
    exit(1);
}
