<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/Core/Bootstrap.php';
\EstoqueMed\Core\Bootstrap::init(false);
use EstoqueMed\Seeds\Seeder;
if(PHP_SAPI!=='cli')exit('Somente CLI');
if(PHP_VERSION_ID<80200){fwrite(STDERR,"ERRO: PHP 8.2 ou superior é obrigatório.\n");exit(1);}
foreach(['PDO','pdo_mysql','json'] as $ext)if(!extension_loaded($ext)){fwrite(STDERR,"ERRO: extensão PHP ausente: $ext\n");exit(1);}
 
if (!class_exists(Seeder::class) || !is_callable([Seeder::class, 'run'])) {
    fwrite(STDERR,"ERRO: componente de dados iniciais ausente (seeds/Seeder.php).\n");
    exit(1);
}
function ask(string $prompt,string $default='',bool $secret=false):string {echo $prompt.($default!==''?' ['.$default.']':'').': ';$v=trim((string)fgets(STDIN));return $v!==''?$v:$default;}
function sqlStatements(string $content):array {  
 return array_values(array_filter(array_map('trim',preg_split('/;\s*(?:\r?\n|$)/',preg_replace('/^\s*--.*$/m','',$content)))));
}
$envPath=dirname(__DIR__).'/.env';
if(is_file($envPath)){echo "Já existe .env; esta instalação não substitui uma instalação existente.\n";exit(2);}
try {
 echo "\nEstoqueMed_Mb — INSTALADOR SEGURO\n";
 $host=ask('Host MariaDB/MySQL','127.0.0.1');$port=ask('Porta','3306');
 $name=ask('Nome do banco (será criado se necessário)','estoquemed_mb');
 if(!preg_match('/^[a-zA-Z0-9_]+$/',$name))throw new RuntimeException('Nome de banco inválido.');
 $user=ask('Usuário do banco','root');$password=ask('Senha do banco (entrada visível no terminal)');
 $pdo=new PDO("mysql:host=$host;port=$port;charset=utf8mb4",$user,$password,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_EMULATE_PREPARES=>false]);
 $pdo->exec('CREATE DATABASE IF NOT EXISTS `'.$name.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
 $pdo->exec('USE `'.$name.'`');
  
  
 $knownTables=['organizations','units','users','login_attempts','medications','suppliers',
  'supplier_products','devices','locations','batches','stock_reservations',
  'stock_movements','consumption_history','purchase_recommendations',
  'purchase_orders','purchase_order_items','receipts','temperature_readings',
  'temperature_incidents','integration_events','alerts','analytics_runs',
  'audit_logs','system_settings'];
 $existingTables=$pdo->query("SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE'")->fetchAll(PDO::FETCH_COLUMN);
 $existingKnown=array_values(array_intersect($knownTables,$existingTables));
 if($existingKnown!==[]){
      
     foreach(['organizations','medications','users'] as $required){
         if(!in_array($required,$existingKnown,true)){
             throw new RuntimeException('Banco contem tabelas preexistentes de origem nao identificada. Escolha outro nome de banco; nenhum dado foi alterado.');
         }
     }
     foreach($existingKnown as $table){
         if($pdo->query('SELECT 1 FROM `'.$table.'` LIMIT 1')->fetchColumn()!==false){
             throw new RuntimeException('Banco ja contem registros (tabela '.$table.'). A instalacao nao sobrescrevera dados.');
         }
     }
     echo "\n[RECUPERACAO] Estrutura existente sem registros: continuando a instalacao interrompida.\n";
 }
 $schema=file_get_contents(dirname(__DIR__).'/database/schema.sql');
 if($schema===false)throw new RuntimeException('Arquivo database/schema.sql nao encontrado.');
 foreach(sqlStatements($schema) as $stmt)$pdo->exec($stmt);
 $initial=bin2hex(random_bytes(9));
 $data=Seeder::run($pdo,$initial);
 $value=static fn($s)=>'"'.str_replace(['\\','"',"\n", "\r"],['\\\\','\\"','',''],$s).'"';
 $settings=['APP_TIMEZONE'=>'America/Sao_Paulo','DB_HOST'=>$host,'DB_PORT'=>$port,'DB_NAME'=>$name,'DB_USER'=>$user,'DB_PASSWORD'=>$password];
 $lines=[];foreach($settings as $k=>$v)$lines[]=$k.'='.$value($v);
 if(file_put_contents($envPath,implode("\n",$lines)."\n",LOCK_EX)===false)throw new RuntimeException('Falha ao salvar .env');
 if(DIRECTORY_SEPARATOR==='/')chmod($envPath,0600);
 echo "\nINSTALAÇÃO CONCLUÍDA\nUsuário: admin@estoquemed.local\nSenha gerada (ANOTE E ALTERE): $initial\nRegistros iniciais: ".json_encode($data)."\nAcesso pelo Apache: http://localhost/EstoqueMed_Mb/public/\nAlternativa: php -S 127.0.0.1:8080 -t public public/router.php\n";
} catch(Throwable $e){fwrite(STDERR,"INSTALAÇÃO NÃO CONCLUÍDA: ".$e->getMessage()."\n");exit(1);}
