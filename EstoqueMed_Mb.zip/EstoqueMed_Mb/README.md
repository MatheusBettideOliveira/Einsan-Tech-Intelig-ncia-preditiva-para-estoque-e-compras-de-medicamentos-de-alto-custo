# EstoqueMed_Mb — Hackathon Connect 7.0

**Inteligência que antecipa. Decisões que protegem.**

Aplicação web para rastreabilidade, projeção de consumo, gestão de lotes e recomendações explicáveis de reposição de medicamentos fictícios de alto custo. **Não é software clínico homologado.** Todos os medicamentos, fornecedores e medições incluídos no seed são fictícios. A interface com o cofre *Medical Security* é uma **simulação, sem integração técnica real validada**.

## Funcionalidades

- Backend PHP sem framework obrigatório; API JSON, sessão e proteção CSRF.
- Frontend HTML, CSS e JavaScript locais, com layout responsivo, temas claro/escuro, gráficos SVG e tabelas filtráveis e paginadas.
- Schema MySQL/MariaDB, seed reproduzível, instalador CLI e scripts Windows.
- Estoque por lote, reservas, alocação FEFO, entrada, consumo, ajustes, transferência integral, descarte, bloqueio, estorno e auditoria.
- Previsão determinística com validação temporal e cinco métodos concorrentes.
- Reposição por fornecedor com restrições de orçamento, capacidade, prazos, embalagem e validade; recomendações explicadas e aprovação manual.
- Simulador de cenários para cenários hipotéticos; replay comparativo tradicional versus inteligente.
- Fluxo de sugestão/aprovação/pedido/recebimento parcial; eventos térmicos de equipamentos **simulados**.
- Relatórios CSV e PDF gerados localmente; roteiro guiado da apresentação.

## Requisitos

- **PHP 8.2 ou superior**, com `PDO`, extensão **`pdo_mysql`**, `json` e `openssl` habilitadas.
- **MySQL 8+ ou MariaDB 10.6+**, com InnoDB e usuário autorizado a criar banco/tabelas.
- Windows + XAMPP, WampServer, Apache/PHP ou hospedagem que permita PHP e banco compatível.
- Não requer Docker, Python, Node, CDN nem API paga em tempo de execução.
- Recomendação: ambiente de teste isolado, usando **somente dados sintéticos**.

## Instalação (Windows/XAMPP)

1. Extraia a pasta `EstoqueMed_Mb` no diretório `C:\xampp\htdocs\EstoqueMed_Mb` (ou outro local escolhido).
2. Inicie **MySQL/MariaDB** e **Apache** no painel do XAMPP. Confirme `pdo_mysql` no PHP usado pelo instalador.
3. Execute **`INSTALAR.bat`** a partir da pasta raiz. Informe host, porta, banco e usuário/senha do MySQL. O instalador recusa sobrescrever uma instalação existente com registros. **Se uma tentativa anterior criou somente tabelas vazias e falhou antes do seed, o instalador identifica a estrutura do EstoqueMed_Mb e permite continuar sem apagar o banco.**
4. **Anote a senha aleatória do administrador** exibida na instalação; não há senha fixa publicada no código.
5. Execute **`INICIAR.bat`**. Pelo XAMPP, o endereço padrão é `http://localhost/EstoqueMed_Mb/public/`. Se Apache não for encontrado, o script tenta iniciar o servidor PHP embutido em `http://127.0.0.1:8080/`.
6. No login, use `admin@estoquemed.local` e a senha gerada. Troque-a no ícone de configurações após o acesso.

**Alternativa CLI:** rode `php scripts/setup.php` em terminal, em seguida `php -S 127.0.0.1:8080 -t public public/router.php`. O instalador é interativo; não sobrescreva o `.env` manualmente sem fazer backup. A senha do banco informada no terminal de configuração permanece no arquivo privado `.env` para permitir conexão.

**Hospedagem compartilhada:** configure o DocumentRoot para `public/`, mantendo `app/`, `seeds/`, `docs/`, `storage/`, `.env` e `scripts/` fora da raiz acessível da web. Caso a hospedagem obrigue usar `public_html`, publique **somente** os arquivos de `public/` nesse diretório e mantenha as demais pastas fora dele, ajustando caminhos do bootstrap com assistência técnica. Não exponha a raiz inteira a requisições HTTP.

## Apresentação à banca

Depois de entrar, clique em **Iniciar apresentação** no painel geral, ou **Apresentação guiada** na barra lateral. Avance pelas seis etapas: problema → previsão → recomendação → imprevisto → alternativa → comparativo de custo. Para variar parâmetros livremente, abra **Simulador de cenários**. Use medicamentos e lotes fictícios do seed.

## Testes e backup

- `TESTAR.bat` executa o conjunto sem banco e realiza diagnóstico do banco quando disponível, registrando `storage/logs/resultado_testes.txt`.
- Via CLI: `APP_PHP_LINT=1 php tests/run.php` (Linux/macOS) ou `set APP_PHP_LINT=1 && php tests\run.php` (Windows).
- `php scripts/test_db.php` verifica conexão e integridade básica de uma instalação já configurada. **Esse teste é condicional**; sem `pdo_mysql`, informa SKIP.
- `BACKUP.bat` guarda dump `.sql.gz` e cópia sensível do `.env` em `storage/backups/`, com retenção de sete backups. Proteja a pasta e considere cifrar cópias externas.

## Estrutura do projeto

`app/Core` autenticação e persistência; `app/Algorithms` modelos; `app/Services` operações; `public/` interface, arquivos e endpoints; `database/` schema; `seeds/` dados fictícios; `scripts/` instalador e utilitários; `tests/` testes automatizados; `docs/` arquitetura, modelos, demonstração e limitações; `storage/` logs e backups privados.

## Limitações relevantes

A integração física não foi implementada. A seleção de fornecedor usa **enumeração heurística de ofertas unitárias**, sem provar ótimo global ou combinação de fornecedores. A comparação de estratégias opera sobre hipóteses de simulação e não demonstra economia realizada. Autorização do responsável técnico continua exigida para uso de qualquer lote após incidente de temperatura. Ver `docs/LIMITACOES.md`, `docs/TESTES.md` e `docs/OTIMIZACAO_COMPRAS.md`.

Nenhum resultado deste protótipo deve ser usado para dispensação automática ou para decisões de compra reais sem revisão, calibração estatística, dados certificados, testes operacionais e validação regulatória aplicável.
