<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/Core/Bootstrap.php';
\EstoqueMed\Core\Bootstrap::init(false);
use EstoqueMed\Algorithms\ForecastEngine;
use EstoqueMed\Services\SimplePdf;
use EstoqueMed\Core\Input;
$passes=0;$fails=0;
function check(string $name,bool $test):void{global $passes,$fails;if($test){$passes++;echo "[PASS] $name\n";}else{$fails++;echo "[FAIL] $name\n";}}
function near(float $a,float $b,float $eps=.001):bool{return abs($a-$b)<=$eps;}
check('Autocarregamento da classe EstoqueMed\Seeds\Seeder', class_exists(\EstoqueMed\Seeds\Seeder::class));
$x=array_fill(0,180,4);$f=ForecastEngine::predict($x,30);
check('Demanda constante: 4 unidades/dia',near($f['daily'],4));
check('Demanda constante: 120 unidades em 30 dias',near($f['total'],120));
check('Validação temporal: 30 ou menos observações reservadas',$f['validation_days']>0 && $f['validation_days']<=30);
check('Demanda vazia: insuficiente',ForecastEngine::predict([],30)['model']==='insufficient');
check('Histórico curto: confiança limitada',str_contains(ForecastEngine::predict([1,2,3],7)['confidence'],'insuficiente'));
$z=ForecastEngine::predict(array_fill(0,90,0),15);
check('Demanda nula: total nulo',near($z['total'],0));
check('Denominador WAPE zero tratado como N/D',$z['metrics']['naive']['wape']===null);
$s=array_fill(0,180,0);for($i=0;$i<180;$i+=10)$s[$i]=8;
$inter=ForecastEngine::predict($s,30);
check('Demanda intermitente: taxa não negativa',$inter['daily']>=0&&is_finite($inter['daily']));
check('Croston SBA implementado com previsão não negativa',ForecastEngine::one($s,'croston_sba')>0);
$up=array_map(static fn($v)=>$v/2,range(1,180));
$trend=ForecastEngine::predict($up,15);
check('Demanda crescente: previsão numérica finita',is_finite($trend['daily'])&&$trend['daily']>0);
check('Previsões reproduzíveis',json_encode($trend)===json_encode(ForecastEngine::predict($up,15)));
$hasValid=Input::date('2026-11-14')==='2026-11-14';check('Validação de data válida',$hasValid);
try{Input::date('2026-02-30');check('Data inválida rejeitada',false);}catch(Throwable){check('Data inválida rejeitada',true);}
$pdf=SimplePdf::render('Relatório teste',[['item'=>'Linha teste','valor'=>123]]);
check('PDF gerado localmente',str_starts_with($pdf,'%PDF-1.4') && str_contains($pdf,'%%EOF'));
check('PDF contém conteúdo',str_contains($pdf,'Linha teste'));
$native=getenv('APP_PHP_LINT');
if($native){$files=new RecursiveIteratorIterator(new RecursiveDirectoryIterator(dirname(__DIR__)));$all=true;foreach($files as $file)if($file->isFile()&&$file->getExtension()==='php'){$output=[];$code=0;exec(escapeshellarg(PHP_BINARY).' -l '.escapeshellarg($file->getPathname()),$output,$code);if($code!==0){$all=false;echo implode("\n",$output)."\n";}}check('Linter PHP: todos os arquivos',$all);}
echo "\nResultado: $passes aprovados; $fails falhas.\n";exit($fails>0?1:0);
