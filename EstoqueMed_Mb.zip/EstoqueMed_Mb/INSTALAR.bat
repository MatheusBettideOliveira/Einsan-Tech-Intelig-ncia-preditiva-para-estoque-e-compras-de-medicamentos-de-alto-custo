@echo off
setlocal
cd /d "%~dp0"
call :locatephp
if errorlevel 1 goto :fail
"%PHP_BIN%" scripts\setup.php
if errorlevel 1 goto :fail
echo.
echo Instale/abra Apache e MySQL no XAMPP, entao execute INICIAR.bat.
pause
exit /b 0
:locatephp
set "PHP_BIN=php"
where php >nul 2>nul
if not errorlevel 1 exit /b 0
if exist "C:\xampp\php\php.exe" set "PHP_BIN=C:\xampp\php\php.exe"&exit /b 0
if exist "C:\wamp64\bin\php\php8.2.0\php.exe" set "PHP_BIN=C:\wamp64\bin\php\php8.2.0\php.exe"&exit /b 0
echo PHP nao localizado. Instale PHP 8.2+ ou XAMPP.
exit /b 1
:fail
echo Instalacao interrompida. Consulte README.md e corrija o diagnostico acima.
pause
exit /b 1
