@echo off
setlocal
cd /d "%~dp0"
set "PHP_BIN=php"
where php >nul 2>nul
if errorlevel 1 if exist "C:\xampp\php\php.exe" set "PHP_BIN=C:\xampp\php\php.exe"
"%PHP_BIN%" scripts\backup.php
if errorlevel 1 echo Falha no backup: confira os requisitos de ambiente.
echo ATENCAO: arquivos de backup sao confidenciais e devem permanecer fora da area publica.
pause
