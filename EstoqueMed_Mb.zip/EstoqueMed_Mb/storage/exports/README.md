Pasta reservada a arquivos locais de exportação. Não publique.
