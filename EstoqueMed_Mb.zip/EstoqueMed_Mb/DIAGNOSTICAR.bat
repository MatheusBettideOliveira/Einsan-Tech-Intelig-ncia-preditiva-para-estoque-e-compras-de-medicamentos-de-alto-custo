@echo off
setlocal
cd /d "%~dp0"
set "PHP_BIN=C:\xampp\php\php.exe"
if not exist "%PHP_BIN%" set "PHP_BIN=php"
if not exist "storage\logs" mkdir "storage\logs"
"%PHP_BIN%" scripts\diagnosticar.php > "storage\logs\diagnostico_banco.txt" 2>&1
set "STATUS=%ERRORLEVEL%"
type "storage\logs\diagnostico_banco.txt"
echo.
echo Relatorio: storage\logs\diagnostico_banco.txt
if not "%STATUS%"=="0" echo VERIFICACAO COM FALHAS. Se a estrutura estiver incompleta, execute ATUALIZAR_BANCO.bat.
pause
exit /b %STATUS%
