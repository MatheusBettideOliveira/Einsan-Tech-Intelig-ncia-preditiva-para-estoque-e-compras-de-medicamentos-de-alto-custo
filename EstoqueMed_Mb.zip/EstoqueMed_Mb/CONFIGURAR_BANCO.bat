@echo off
setlocal
cd /d "%~dp0"
set "PHP_BIN=C:\xampp\php\php.exe"
if not exist "%PHP_BIN%" set "PHP_BIN=php"
"%PHP_BIN%" scripts\configurar_banco.php
set "STATUS=%ERRORLEVEL%"
if "%STATUS%"=="0" echo Configuracao concluida. Abra novamente o EstoqueMed_Mb.
pause
exit /b %STATUS%
