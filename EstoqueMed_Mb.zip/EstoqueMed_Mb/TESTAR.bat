@echo off
setlocal
cd /d "%~dp0"
set "PHP_BIN=php"
where php >nul 2>nul
if errorlevel 1 if exist "C:\xampp\php\php.exe" set "PHP_BIN=C:\xampp\php\php.exe"
if not exist "storage\logs" mkdir "storage\logs"
set "APP_PHP_LINT=1"
"%PHP_BIN%" tests\run.php > "storage\logs\resultado_testes.txt" 2>&1
set "EXIT_CODE=%ERRORLEVEL%"
"%PHP_BIN%" scripts\test_db.php >> "storage\logs\resultado_testes.txt" 2>&1
set "DB_EXIT_CODE=%ERRORLEVEL%"
if "%DB_EXIT_CODE%"=="1" set "EXIT_CODE=1"
type "storage\logs\resultado_testes.txt"
if "%DB_EXIT_CODE%"=="2" echo ATENCAO: testes de banco ignorados - MySQL nao configurado.
if not "%EXIT_CODE%"=="0" echo ATENCAO: houve falha em algum teste.
pause
exit /b %EXIT_CODE%
