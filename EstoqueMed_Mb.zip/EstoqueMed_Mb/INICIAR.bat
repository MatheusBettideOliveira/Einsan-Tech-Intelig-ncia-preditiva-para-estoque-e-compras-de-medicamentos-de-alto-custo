@echo off
setlocal
cd /d "%~dp0"
if not exist ".env" (echo Execute INSTALAR.bat primeiro.&pause&exit /b 1)
set "URL=http://localhost/EstoqueMed_Mb/public/"
curl -s -I --max-time 3 "%URL%" >nul 2>nul
if not errorlevel 1 (start "" "%URL%"&exit /b 0)
set "PHP_BIN=php"
where php >nul 2>nul
if errorlevel 1 if exist "C:\xampp\php\php.exe" set "PHP_BIN=C:\xampp\php\php.exe"
echo Apache nao encontrado na URL padrao. Abrindo servidor PHP local 127.0.0.1:8080...
start "EstoqueMed_Mb - servidor local" cmd /k ""%PHP_BIN%" -S 127.0.0.1:8080 -t public public/router.php"
timeout /t 2 >nul
start "" "http://127.0.0.1:8080/"
exit /b 0
