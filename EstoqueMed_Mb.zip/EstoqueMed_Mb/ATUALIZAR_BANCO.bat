@echo off
setlocal
cd /d "%~dp0"
set "PHP_BIN=C:\xampp\php\php.exe"
if not exist "%PHP_BIN%" set "PHP_BIN=php"
if not exist ".env" (echo Conexao nao configurada. Execute INSTALAR.bat primeiro.&pause&exit /b 1)
echo Atualizacao segura do banco EstoqueMed_Mb
"%PHP_BIN%" scripts\atualizar_banco.php
set "STATUS=%ERRORLEVEL%"
if not "%STATUS%"=="0" (echo Atualizacao incompleta. Nenhum registro foi apagado.&pause&exit /b %STATUS%)
call DIAGNOSTICAR.bat
exit /b %ERRORLEVEL%
