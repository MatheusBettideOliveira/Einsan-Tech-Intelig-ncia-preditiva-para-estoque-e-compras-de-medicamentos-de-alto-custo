Arquivos privados de configuração devem ficar fora da raiz pública.
