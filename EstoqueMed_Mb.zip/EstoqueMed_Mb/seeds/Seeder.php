<?php
declare(strict_types=1);
namespace EstoqueMed\Seeds;
use PDO;
final class Seeder {
    public static function run(PDO $db,string $adminPassword):array {
        $db->beginTransaction();
        try {
            $existing=(int)$db->query('SELECT COUNT(*) FROM medications')->fetchColumn();
            if($existing>0)throw new \RuntimeException('A base já contém medicamentos. Seed não aplicada para preservar os dados.');
            mt_srand(7002026);
            $db->exec("INSERT INTO organizations(name) VALUES('Rede Vida Plena')");
            foreach(['Hospital Aurora','Clínica Horizonte','Centro Médico Solaris'] as $name)$db->prepare('INSERT INTO units(organization_id,name) VALUES(1,?)')->execute([$name]);
            $hash=password_hash($adminPassword,PASSWORD_DEFAULT);
            $db->prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)')->execute(['Administrador','admin@estoquemed.local',$hash,'admin']);
            $meds=['BioNexa Alpha','ImunoVita Beta','OncoGuard Gamma','NeuroCare Delta','RenalFix Epsilon','HemaLume Zeta','CardioNex Eta','ImunoNex Theta','BioGuard Iota','CytoNex Kappa','OncoVital Lambda','HemaCell Mu','NeuroMed Nu','VitaCore Xi','ImunoCare Omicron','BioShield Pi','RenalNex Rho','HemaGuard Sigma','OncoLume Tau','NeuroVital Upsilon','CardioCore Phi','CytoCare Chi','VitaNexa Psi','ImunoLume Omega','BioCell A1','HemaNex B2','RenalGuard C3','OncoCore D4','NeuroShield E5','CytoVital F6'];
            $cats=['Biotecnológico','Imunoterapia','Oncologia','Terapia especializada','Hematologia'];
            $stmt=$db->prepare('INSERT INTO medications(code,name,generic_name,active_ingredient,presentation,concentration,manufacturer,category,refrigerated,temp_min,temp_max,min_stock,safety_stock,max_stock,reference_price,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            foreach($meds as $i=>$name){
                $ref=round(680+(($i*1373)%9000)+($i%5)*.53,2);
                $stmt->execute([sprintf('MED-%03d',$i+1),$name,'Substância modelo '.($i+1),'Ativo de referência '.($i+1),'Frasco refrigerado','Concentração não especificada','Laboratório '.($i%6+1),$cats[$i%5],1,$i%3===0?2:($i%3===1?3:0),$i%3===0?8:($i%3===1?7:10),5+$i%4,8+$i%7,75+$i%6*14,$ref,'Produto e atributos totalmente fictícios; não usar como referência clínica.']);
            }
            $names=['Pharma Alfa','Distribuidora Beta','Saúde Express','Logística Gama','BioTrade','Hospital Supply','Nexus Distribuição','Prime Med'];
            foreach($names as $i=>$n)$db->prepare('INSERT INTO suppliers(name,identifier,contact,reliability) VALUES(?,?,?,?)')->execute([$n,sprintf('CNPJ-FICTICIO-%02d',$i+1),'contato-ficticio-'.$i.'@example.invalid',round(.72+(($i*3)%8)*.035,4)]);
            for($unit=1;$unit<=3;$unit++){
                $db->prepare('INSERT INTO devices(unit_id,name,code,temperature,door_open,status,last_sync) VALUES(?,?,?,?,0,\'normal\',NOW())')->execute([$unit,'Cofre refrigerado — Unidade '.$unit,'CF-'.str_pad((string)$unit,3,'0',STR_PAD_LEFT),4.5]);
                $db->prepare('INSERT INTO locations(unit_id,device_id,name,capacity) VALUES(?,?,?,?)')->execute([$unit,$unit,'Compartimento refrigerado '.$unit,1500]);
            }
            $offer=$db->prepare('INSERT INTO supplier_products(supplier_id,medication_id,unit_price,lead_days,lead_min_days,lead_max_days,min_order,pack_multiple,freight) VALUES(?,?,?,?,?,?,?,?,?)');
            foreach($meds as $i=>$m){
                $ref=round(680+(($i*1373)%9000)+($i%5)*.53,2);
                for($k=0;$k<4;$k++){
                    $sup=($i+$k*2)%8+1;$lead=($k===0?14:($k===1?3:($k===2?7:11)))+$i%3;
                    $price=round($ref*([.94,1.08,1.00,.97][$k]),2);
                    $offer->execute([$sup,$i+1,$price,$lead,max(1,$lead-2),$lead+4,$k===3?5:1,$k===3?5:1,$k===1?95:($k===2?30:0)]);
                }
            }
            $batch=$db->prepare('INSERT INTO batches(medication_id,lot_number,manufacturer,manufactured_at,expires_at,received_at,initial_quantity,quantity,unit_cost,supplier_id,location_id,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)');
            $today=new \DateTimeImmutable('today');
            for($i=0;$i<30;$i++) for($j=0;$j<3+($i%3===0?1:0);$j++){
                $qty=($i%7===0?2:($i%6===0?90:12+($i*7+$j*11)%30));
                $expiryDays=($i===2&&$j===0)?-3:(($i===3||$i===9)&&$j===0?12:90+($i*37+$j*43)%270);
                $status=$expiryDays<0?'expired':($i===5&&$j===0?'quarantine':($i===8&&$j===0?'blocked':'available'));
                $cost=round((680+(($i*1373)%9000)+($i%5)*.53)*(.88+($j%3)*.02),2);
                $batch->execute([$i+1,sprintf('LOT-%02d-%02d',$i+1,$j+1),'Laboratório '.($i%6+1),$today->modify('-250 days')->format('Y-m-d'),$today->modify(($expiryDays>=0?'+':'').$expiryDays.' days')->format('Y-m-d'),$today->modify('-'.(10+$j*12).' days')->format('Y-m-d'),$qty,$qty,$cost,($i+$j)%8+1,($i+$j)%3+1,$status]);
            }
            $hist=$db->prepare("INSERT INTO consumption_history(medication_id,unit_id,consumed_on,quantity,source) VALUES(?,?,?,?, 'historical')");
            for($m=1;$m<=30;$m++){
                $first=$m===5?14:180;
                for($d=$first-1;$d>=0;$d--){
                    $date=$today->modify('-'.$d.' days')->format('Y-m-d');
                    $base=1+($m%4);
                    if($m%8===2)$base+=(int)floor((180-$d)/36);
                    if($m%8===3)$base=($d%8===0)?6:0;
                    if($m%8===4)$base=($d%19===0)?10:(($d%3===0)?0:1);
                    if($m%8===5)$base=(int)($d%5===0?8:($d%2===0?3:0));
                    $base=max(0,$base+mt_rand(-1,1));
                    $unit=$m%3+1;
                    $hist->execute([$m,$unit,$date,$base]);
                }
            }
            $t=$db->prepare("INSERT INTO temperature_readings(device_id,temperature,recorded_at,source) VALUES(?,?,?,'simulated')");
            for($dev=1;$dev<=3;$dev++)for($h=72;$h>=0;$h--){$temp=round(4.5+.8*sin($h/7+$dev)+mt_rand(-20,20)/100,2);$t->execute([$dev,$temp,$today->modify('-'.$h.' hours')->format('Y-m-d H:i:s')]);}
            $db->exec("INSERT INTO alerts(dedupe_key,level,type,description,entity_type,entity_id) VALUES('alerta-validade','warning','expiry','Lote próximo do vencimento','batches',14),('alerta-estoque','critical','stockout','Medicamento sob risco de ruptura','medications',1),('alerta-consumo','info','forecast','Previsões são estimativas e exigem validação','medications',5)");
            $db->exec("INSERT INTO system_settings(setting_key,setting_value) VALUES('seed_version','7.0'),('simulation_only','1')");
             
            $db->exec("INSERT INTO purchase_orders(supplier_id,status,expected_at,created_by) VALUES(1,'partially_received',DATE_ADD(CURDATE(),INTERVAL 5 DAY),1)");
            $db->exec('INSERT INTO purchase_order_items(order_id,medication_id,quantity,received_quantity,unit_price) VALUES(1,1,10,3,639.20)');
            $db->exec("INSERT INTO receipts(event_key,order_item_id,batch_id,quantity,received_by) VALUES('recebimento-inicial-1',1,1,3,1)");
            $db->exec("INSERT INTO stock_movements(event_key,batch_id,medication_id,movement_type,quantity,source_location_id,reason,user_id,related_entity,related_id) VALUES('entrada-inicial-1',1,1,'entry',3,1,'Recebimento parcial',1,'receipt','1')");
            $db->exec('UPDATE batches SET quantity=quantity+3,initial_quantity=initial_quantity+3 WHERE id=1');
            $db->commit();return ['medications'=>30,'batches'=>(int)$db->query('SELECT COUNT(*) FROM batches')->fetchColumn(),'suppliers'=>8,'history_days'=>180];
        } catch(\Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
    }
}
