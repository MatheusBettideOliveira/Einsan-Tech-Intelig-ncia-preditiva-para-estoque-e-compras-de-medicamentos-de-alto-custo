<?php
declare(strict_types=1);
namespace EstoqueMed\Services;

final class CompactZip {
    public static function pack(array $entries):string {
        $result='';$directory='';$count=0;
        $now=getdate();
        $dosTime=(($now['hours']&31)<<11)|(($now['minutes']&63)<<5)|((int)($now['seconds']/2)&31);
        $dosDate=((max(1980,$now['year'])-1980)<<9)|(($now['mon']&15)<<5)|($now['mday']&31);
        foreach ($entries as $name=>$contents) {
            $name=str_replace('\\','/',$name);
            if ($name===''||str_starts_with($name,'/')||str_contains($name,'../')||str_contains($name,"\0"))throw new \RuntimeException('Arquivo inválido no pacote.');
            $raw=(string)$contents;
            $deflated=function_exists('gzdeflate')?gzdeflate($raw,6):false;
            $compressed=$deflated===false?$raw:$deflated;
            $method=$deflated===false?0:8;
            $crc=crc32($raw);
            $length=strlen($raw);$packedLength=strlen($compressed);
            $offset=strlen($result);
            $nameLength=strlen($name);
            $result.=pack('VvvvvvVVVvv',0x04034b50,20,0,$method,$dosTime,$dosDate,$crc,$packedLength,$length,$nameLength,0).$name.$compressed;
            $directory.=pack('VvvvvvvVVVvvvvvVV',0x02014b50,20,20,0,$method,$dosTime,$dosDate,$crc,$packedLength,$length,$nameLength,0,0,0,0,0,$offset).$name;
            $count++;
        }
        if($count>65535)throw new \RuntimeException('Número de arquivos acima do limite.');
        return $result.$directory.pack('VvvvvVVv',0x06054b50,0,0,$count,$count,strlen($directory),strlen($result),0);
    }
}
