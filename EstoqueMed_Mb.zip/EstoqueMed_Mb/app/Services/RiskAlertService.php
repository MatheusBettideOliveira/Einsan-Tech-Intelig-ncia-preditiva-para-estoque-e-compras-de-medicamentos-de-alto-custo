<?php
declare(strict_types=1);
namespace EstoqueMed\Services;
use EstoqueMed\Core\DB;
use EstoqueMed\Algorithms\ForecastEngine;

 
final class RiskAlertService {
    public static function refresh(): void {
        foreach (DB::all('SELECT id,name,min_stock,safety_stock FROM medications WHERE active=1') as $m) {
            $id=(int)$m['id'];
            $historical=AnalyticsService::history($id);
            $f=ForecastEngine::predict($historical['series'],30);
            if($f['observations']<21) {
                self::upsert('data-'.$id,'info','insufficient_history','Histórico insuficiente para projeção confiável: '.$m['name'],'medications',$id);
                continue;
            }
            $available=DecisionEngine::stock($id)['available'];
            $threshold=(int)ceil(max((int)$m['min_stock'],7*$f['daily']+(int)$m['safety_stock']));
            if($available<$threshold){
                self::upsert('stock-'.$id,'critical','stockout','Risco de ruptura: '.$m['name'].' possui '.$available.' un. livres para referência mínima de '.$threshold.'.','medications',$id);
            }
        }
        foreach (DB::all("SELECT b.id,b.lot_number,b.expires_at,m.name,b.quantity,b.status FROM batches b JOIN medications m ON m.id=b.medication_id WHERE b.quantity>0 AND b.status NOT IN ('discarded','depleted') AND b.expires_at<=DATE_ADD(CURDATE(),INTERVAL 30 DAY)") as $b) {
            $expired=$b['expires_at']<date('Y-m-d');
            self::upsert('expiry-'.$b['id'],$expired?'critical':'warning',$expired?'expired':'expiry',($expired?'Lote vencido: ':'Validade próxima: ').$b['lot_number'].' — '.$b['name'].' ('.$b['expires_at'].').','batches',(int)$b['id']);
        }
    }
    private static function upsert(string $key,string $level,string $type,string $description,string $entity,int $id): void {
        DB::run("INSERT INTO alerts(dedupe_key,level,type,description,entity_type,entity_id) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE level=VALUES(level),description=VALUES(description)",[$key,$level,$type,$description,$entity,$id]);
    }
}
