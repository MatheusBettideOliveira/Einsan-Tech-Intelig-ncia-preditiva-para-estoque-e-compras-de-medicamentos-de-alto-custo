<?php
declare(strict_types=1);
namespace EstoqueMed\Services;
use EstoqueMed\Core\{DB,HttpException};

final class PresentationService {
    private static function money(float|int $value):string {
        return 'R$ '.number_format((float)$value,2,',','.');
    }
    private static function number(float|int $value,int $precision=0):string {
        return number_format((float)$value,$precision,',','.');
    }
    private static function label(string $model):string {
        return [
            'naive'=>'Consumo recente',
            'moving_average'=>'Média móvel',
            'weighted_average'=>'Média móvel ponderada',
            'exponential'=>'Suavização exponencial',
            'croston_sba'=>'Demanda intermitente',
            'insufficient'=>'Histórico insuficiente'
        ][$model]??'Método estatístico';
    }
    private static function short(string $value,int $limit):string {
        $value=trim(preg_replace('/\s+/u',' ',$value)??$value);
        if(function_exists('mb_strlen')&&function_exists('mb_substr')) return mb_strlen($value,'UTF-8')>$limit?mb_substr($value,0,$limit-1,'UTF-8').'…':$value;
        $characters=preg_split('//u',$value,-1,PREG_SPLIT_NO_EMPTY);
        if(is_array($characters))return count($characters)>$limit?implode('',array_slice($characters,0,max(1,$limit-1))).'…':$value;
        return strlen($value)>$limit?substr($value,0,$limit-3).'...':$value;
    }
    public static function data(int $medicationId,int $horizon=30,int $comparisonDays=60):array {
        if(!in_array($horizon,[7,15,30,60,90],true)||!in_array($comparisonDays,[30,60,90],true))throw new HttpException(422,'Selecione um período válido.');
        $med=DB::one('SELECT id,name FROM medications WHERE id=? AND active=1',[$medicationId]);
        if(!$med)throw new HttpException(404,'Medicamento não encontrado.');
        $dashboard=AnalyticsService::dashboard(30);
        $forecast=AnalyticsService::forecast($medicationId,$horizon)['forecast'];
        $recommendation=DecisionEngine::recommendation($medicationId,['horizon'=>$horizon]);
        $lots=DB::all('SELECT lot_number,expires_at,quantity,status FROM batches WHERE medication_id=? ORDER BY expires_at,id',[$medicationId]);
        $nextExpiry='Não disponível';
        foreach($lots as $lot){
            if((int)$lot['quantity']>0&&$lot['expires_at']>=date('Y-m-d')&&$lot['status']==='available'){
                $nextExpiry=date('d/m/Y',strtotime((string)$lot['expires_at']));break;
            }
        }
        $growth=DecisionEngine::scenario($medicationId,['horizon'=>$horizon,'growth_pct'=>30]);
        $delay=DecisionEngine::scenario($medicationId,['horizon'=>$horizon,'lead_variation'=>7]);
        $comparison=null;$comparisonError=null;
        try{$comparison=ComparisonService::compare($medicationId,$comparisonDays);}
        catch(HttpException $exception){$comparisonError=$exception->getMessage();}
        $result=[
            'generated_at'=>date('d/m/Y H:i'),
            'medication'=>$med['name'],
            'horizon'=>$horizon,
            'comparison_days'=>$comparisonDays,
            'kpis'=>$dashboard['kpis'],
            'lots'=>['count'=>count($lots),'next_expiry'=>$nextExpiry],
            'forecast'=>$forecast,
            'recommendation'=>$recommendation,
            'growth'=>$growth['scenario'],
            'delay'=>$delay['scenario'],
            'comparison'=>$comparison,
            'comparison_unavailable'=>$comparisonError,
            'disclaimer'=>'Indicadores do sistema e cálculos prospectivos; resultados de simulação não são resultados realizados.'
        ];
        return $result;
    }
    public static function render(array $report):string {
        $k=$report['kpis'];$rec=$report['recommendation'];$stock=$rec['stock'];$fc=$report['forecast'];$offers=$rec['offers']??[];
        $comp=$report['comparison'];$supplier=$rec['supplier'];$growth=$report['growth'];$delay=$report['delay'];
        $bestName=$supplier['supplier']??($rec['needed']===0?'Nenhuma compra necessária':'Sem oferta viável');
        $amount=$comp?($comp['net_saving']>=0?'Economia projetada':'Custo adicional projetado'):'Dados insuficientes';
        $tokens=[
            'DATA_GERACAO'=>$report['generated_at'],
            'VALOR_ESTOQUE'=>self::money($k['inventory_value']),
            'MEDICAMENTOS'=>self::number($k['medications']),
            'RISCO_FALTA'=>self::number($k['stockout_risk']),
            'LOTES_VENCER'=>self::number($k['expiring_batches']),
            'MEDICAMENTO'=>self::short((string)$report['medication'],51),
            'SALDO_DISPONIVEL'=>self::number($stock['available']),
            'QTD_LOTES'=>self::number($report['lots']['count']),
            'PROXIMA_VALIDADE'=>$report['lots']['next_expiry'],
            'MEDIA_DIARIA'=>self::number($fc['daily'],2),
            'TOTAL_PREVISTO'=>self::number($fc['total'],1),
            'HORIZONTE'=>(string)$report['horizon'],
            'DIAS_HISTORICO'=>self::number($fc['observations']),
            'MODELO_PREVISAO'=>self::label((string)$fc['model']),
            'CONFIANCA'=>self::short((string)$fc['confidence'],65),
            'QTD_SUGERIDA'=>self::number($rec['quantity']),
            'CUSTO_SUGERIDO'=>self::money($rec['estimated_cost']),
            'PRAZO_ENTREGA'=>isset($supplier['lead_days'])?self::number($supplier['lead_days']).' dias':'Não definido',
            'EXPLICACAO_RESUMIDA'=>self::short('Saldo livre '.$stock['available'].' un., '.$stock['reserved'].' reservadas, '.$stock['incoming'].' a receber e segurança de '.$rec['assumptions']['safety_stock'].' un. '.($rec['needed']===0?'Sem necessidade de compra neste momento.':($supplier?'Fornecedor indicado: '.$bestName.'.':'Nenhuma oferta atende a todas as restrições.')),220),
            'FORNECEDOR_ESCOLHIDO'=>self::short($bestName,74),
            'CENARIO_DEMANDA_QTD'=>self::number($growth['projected_demand'],1).' un.',
            'CENARIO_ATRASO_FALTA'=>self::number($delay['potential_shortage'],1).' un.',
            'CUSTO_TRADICIONAL'=>$comp?self::money($comp['traditional']['total_cost']):'N/D',
            'CUSTO_INTELIGENTE'=>$comp?self::money($comp['smart']['total_cost']):'N/D',
            'DIFERENCA_CUSTO'=>$comp?self::money(abs($comp['net_saving'])):'N/D',
            'ROTULO_DIFERENCA'=>$amount,
            'ATENDIMENTO_TRAD'=>$comp?self::number($comp['traditional']['service_rate'],1).'%':'N/D',
            'ATENDIMENTO_PLAN'=>$comp?self::number($comp['smart']['service_rate'],1).'%':'N/D'
        ];
        for($i=1;$i<=3;$i++){
            $offer=$offers[$i-1]??null;
            $tokens['FORN'.$i.'_NOME']=self::short((string)($offer['supplier']??'Sem oferta cadastrada'),26);
            $tokens['FORN'.$i.'_PRECO']=$offer?self::money($offer['unit_price']):'—';
            $tokens['FORN'.$i.'_PRAZO']=$offer?self::number($offer['lead_days']).' dias':'—';
            $tokens['FORN'.$i.'_CONFIANCA']=$offer?self::number($offer['reliability']*100,1).'%':'—';
        }
        $replace=[];
        foreach($tokens as $key=>$value)$replace['{{'.$key.'}}']=htmlspecialchars(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/','',(string)$value)??'',ENT_XML1|ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
        $source=dirname(__DIR__,2).'/resources/apresentacao';
        if(!is_dir($source))throw new \RuntimeException('Modelo de apresentação indisponível.');
        $files=[];$iterator=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($source,\FilesystemIterator::SKIP_DOTS));
        foreach($iterator as $file){
            if(!$file->isFile())continue;
            $path=str_replace('\\','/',substr($file->getPathname(),strlen($source)+1));
            $body=file_get_contents($file->getPathname());if($body===false)throw new \RuntimeException('Erro de leitura do modelo.');
            if(str_ends_with($path,'.xml')||str_ends_with($path,'.rels')){
                $body=strtr($body,$replace);
                if(preg_match('/\{\{[A-Z0-9_]+\}\}/',$body))throw new \RuntimeException('O modelo contém campos não preenchidos.');
            }
            $files[$path]=$body;
        }
        return CompactZip::pack($files);
    }
}
