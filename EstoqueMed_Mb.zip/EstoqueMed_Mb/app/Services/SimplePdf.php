<?php
declare(strict_types=1);
namespace EstoqueMed\Services;
 
final class SimplePdf {
    public static function render(string $title,array $rows):string {
        $headers=$rows?array_keys($rows[0]):[];
        $pages=[];$lines=[[$title,14],['Emitido em '.date('d/m/Y H:i').' | Relatório operacional',9],['',9]];
        $per=37; $all=[];if($headers)$all[]=implode(' | ',array_map(static fn($s)=>mb_substr_safe((string)$s,0,16),$headers));
        foreach($rows as $row){$str=implode(' | ',array_map(static fn($s)=>mb_substr_safe((string)$s,0,18),array_values($row)));$all[]=mb_substr_safe($str,0,115);}
        if(!$rows)$all[]='Sem dados para exibir.';
        foreach($all as $str){if(count($lines)>=$per){$pages[]=$lines;$lines=[[$title.' — continuação',12],['',9]];}$lines[]=[$str,8];}
        if($lines)$pages[]=$lines;
        $objects=[];$add=static function(string $s)use(&$objects):int{$objects[]=$s;return count($objects);};
        $root=$add('');$pageRoot=$add('');$font=$add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');$pageIds=[];
        $logo=null;
        $logoFile=dirname(__DIR__,2).'/public/assets/images/logo_relatorio.jpg';
        if(is_file($logoFile)){
            $bytes=file_get_contents($logoFile);$size=getimagesize($logoFile);
            if($bytes!==false && is_array($size) && $size[0]>0 && $size[1]>0){
                $logo=$add('<< /Type /XObject /Subtype /Image /Width '.(int)$size[0].' /Height '.(int)$size[1].' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '.strlen($bytes).' >>'."\nstream\n".$bytes."\nendstream");
            }
        }
        foreach($pages as $page){$content=$logo!==null?"q\n270 0 0 61 42 771 cm\n/Logo Do\nQ\nBT\n":"BT\n";$y=$logo!==null?745:800;
            foreach($page as [$s,$size]){$encoded=self::escape((string)$s);$content.="/F1 $size Tf 42 $y Td ($encoded) Tj "."-42 -$y Td\n";$y-=($size>=12?23:16);}
            $content.="ET";$stream=$add('<< /Length '.strlen($content).' >>'."\nstream\n".$content."\nendstream");
            $pageIds[]=$add('<< /Type /Page /Parent '.$pageRoot.' 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 '.$font.' 0 R >>'.($logo!==null?' /XObject << /Logo '.$logo.' 0 R >>':'').' >> /Contents '.$stream.' 0 R >>');
        }
        $objects[$pageRoot-1]='<< /Type /Pages /Kids ['.implode(' ',array_map(static fn($i)=>$i.' 0 R',$pageIds)).'] /Count '.count($pageIds).' >>';
        $objects[$root-1]='<< /Type /Catalog /Pages '.$pageRoot.' 0 R >>';
        $pdf="%PDF-1.4\n";$offset=[0];foreach($objects as $i=>$obj){$offset[]=strlen($pdf);$pdf.=($i+1)." 0 obj\n".$obj."\nendobj\n";}
        $start=strlen($pdf);$pdf.="xref\n0 ".(count($objects)+1)."\n0000000000 65535 f \n";for($i=1;$i<=count($objects);$i++)$pdf.=sprintf('%010d 00000 n ', $offset[$i])."\n";
        $pdf.="trailer\n<< /Size ".(count($objects)+1).' /Root '.$root." 0 R >>\nstartxref\n$start\n%%EOF";
        return $pdf;
    }
    private static function escape(string $s):string { $s=iconv('UTF-8','Windows-1252//TRANSLIT',$s) ?: preg_replace('/[^\x20-\x7e]/','?',$s);return str_replace(['\\','(',')'],['\\\\','\\(','\\)'],$s); }
}
function mb_substr_safe(string $s,int $start,int $length):string {return function_exists('mb_substr')?mb_substr($s,$start,$length):substr($s,$start,$length);}
