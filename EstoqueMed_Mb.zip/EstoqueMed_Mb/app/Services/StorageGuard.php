<?php
declare(strict_types=1);
namespace EstoqueMed\Services;

use EstoqueMed\Core\HttpException;
use PDO;

 
final class StorageGuard {
    public static function ensure(PDO $pdo, int $locationId, int $medicationId, int $quantity): void {
        if ($quantity < 0) throw new HttpException(422, 'Quantidade de ingresso inválida.');
        $s=$pdo->prepare('SELECT l.id,l.capacity,l.device_id,d.temperature,d.status device_status,m.refrigerated,m.temp_min,m.temp_max FROM locations l CROSS JOIN medications m LEFT JOIN devices d ON d.id=l.device_id WHERE l.id=? AND m.id=? AND m.active=1 FOR UPDATE');
        $s->execute([$locationId,$medicationId]);
        $row=$s->fetch();
        if (!$row) throw new HttpException(422, 'Local ou medicamento indisponível.');
        if ((int)$row['refrigerated']===1) {
            if ($row['device_id']===null || $row['temperature']===null || $row['device_status']!=='normal') {
                throw new HttpException(409, 'Armazenamento refrigerado indisponível; requer equipamento normal e monitorado.');
            }
            $temp=(float)$row['temperature'];
            if ($temp<(float)$row['temp_min'] || $temp>(float)$row['temp_max']) {
                throw new HttpException(409, 'Conservação incompatível com a faixa térmica do medicamento.');
            }
        }
        $used=$pdo->prepare('SELECT COALESCE(SUM(quantity),0) FROM batches WHERE location_id=?');
        $used->execute([$locationId]);
        if ((int)$used->fetchColumn()+$quantity>(int)$row['capacity']) {
            throw new HttpException(409, 'Capacidade física de armazenamento insuficiente.');
        }
    }
}
