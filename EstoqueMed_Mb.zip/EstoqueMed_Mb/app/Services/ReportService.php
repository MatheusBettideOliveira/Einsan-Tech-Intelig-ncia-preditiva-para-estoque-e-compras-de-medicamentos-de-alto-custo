<?php
declare(strict_types=1);
namespace EstoqueMed\Services;
use EstoqueMed\Core\{DB,HttpException};
final class ReportService {
    public static function data(string $type):array {
        return match($type) {
            'stock'=>DB::all("SELECT m.code codigo,m.name medicamento,b.lot_number lote,b.expires_at validade,b.status situacao,b.quantity saldo,ROUND(b.quantity*b.unit_cost,2) valor,l.name local FROM batches b JOIN medications m ON m.id=b.medication_id JOIN locations l ON l.id=b.location_id ORDER BY m.name,b.expires_at"),
            'movements'=>DB::all('SELECT x.id,x.created_at data,m.name medicamento,b.lot_number lote,x.movement_type operacao,x.quantity quantidade,x.reason motivo,u.name responsavel FROM stock_movements x JOIN medications m ON m.id=x.medication_id JOIN batches b ON b.id=x.batch_id LEFT JOIN users u ON u.id=x.user_id ORDER BY x.id DESC LIMIT 500'),
            'expiry'=>DB::all("SELECT m.name medicamento,b.lot_number lote,b.expires_at validade,b.quantity saldo,b.status situacao,ROUND(b.quantity*b.unit_cost,2) valor FROM batches b JOIN medications m ON m.id=b.medication_id WHERE b.expires_at<=DATE_ADD(CURDATE(),INTERVAL 90 DAY) ORDER BY b.expires_at"),
            'suppliers'=>DB::all('SELECT s.name fornecedor,m.name medicamento,sp.unit_price preco,sp.lead_days prazo_dias,s.reliability confiabilidade FROM supplier_products sp JOIN suppliers s ON s.id=sp.supplier_id JOIN medications m ON m.id=sp.medication_id ORDER BY m.name,sp.unit_price'),
            'orders'=>DB::all('SELECT o.id pedido,o.ordered_at data,s.name fornecedor,o.status situacao,m.name medicamento,i.quantity quantidade,i.received_quantity recebido,i.unit_price preco FROM purchase_orders o JOIN suppliers s ON s.id=o.supplier_id JOIN purchase_order_items i ON i.order_id=o.id JOIN medications m ON m.id=i.medication_id ORDER BY o.id DESC'),
            'audits'=>DB::all('SELECT a.created_at data,a.action acao,a.entity entidade,a.entity_id registro,u.name usuario FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 500'),
            'consumption'=>DB::all('SELECT c.consumed_on data,m.name medicamento,SUM(c.quantity) consumo FROM consumption_history c JOIN medications m ON m.id=c.medication_id WHERE c.consumed_on>=DATE_SUB(CURDATE(),INTERVAL 90 DAY) GROUP BY c.consumed_on,m.id,m.name ORDER BY c.consumed_on DESC,m.name LIMIT 800'),
            'temperature'=>DB::all('SELECT d.name equipamento,t.recorded_at data,t.temperature temperatura,t.source origem FROM temperature_readings t JOIN devices d ON d.id=t.device_id ORDER BY t.recorded_at DESC LIMIT 500'),
            default=>throw new HttpException(422,'Tipo de relatório desconhecido.')
        };
    }
    private static function titulo(string $tipo):string {
        return [
            'stock'=>'Posição de estoque',
            'expiry'=>'Lotes próximos do vencimento',
            'movements'=>'Movimentações de estoque',
            'consumption'=>'Consumo por medicamento',
            'orders'=>'Pedidos de compra',
            'suppliers'=>'Condições dos fornecedores',
            'temperature'=>'Histórico de temperaturas',
            'audits'=>'Histórico de operações'
        ][$tipo] ?? 'Relatório de estoque';
    }
    private static function dadosApresentacao(string $tipo):array {
        $rotulos = [
            'id'=>'Registro', 'codigo'=>'Código', 'medicamento'=>'Medicamento',
            'lote'=>'Lote', 'validade'=>'Validade', 'situacao'=>'Situação',
            'saldo'=>'Quantidade disponível', 'valor'=>'Valor total (R$)',
            'local'=>'Local de armazenamento', 'data'=>'Data',
            'operacao'=>'Tipo de movimentação', 'quantidade'=>'Quantidade',
            'motivo'=>'Motivo', 'responsavel'=>'Responsável', 'fornecedor'=>'Fornecedor',
            'preco'=>'Preço unitário (R$)', 'prazo_dias'=>'Prazo de entrega (dias)',
            'confiabilidade'=>'Pontualidade estimada (%)', 'pedido'=>'Nº do pedido',
            'recebido'=>'Unidades recebidas', 'usuario'=>'Usuário',
            'acao'=>'Operação realizada', 'entidade'=>'Área', 'registro'=>'Nº do registro',
            'consumo'=>'Unidades consumidas', 'equipamento'=>'Equipamento',
            'temperatura'=>'Temperatura (°C)', 'origem'=>'Origem do registro'
        ];
        $situacoes = [
            'available'=>'Disponível', 'reserved'=>'Reservado',
            'quarantine'=>'Em quarentena', 'blocked'=>'Bloqueado',
            'expired'=>'Vencido', 'discarded'=>'Descartado', 'depleted'=>'Esgotado',
            'approved'=>'Aprovado', 'rejected'=>'Rejeitado', 'suggested'=>'Sugerido',
            'ordered'=>'Pedido emitido', 'partially_received'=>'Recebido parcialmente',
            'received'=>'Recebido', 'canceled'=>'Cancelado', 'open'=>'Aberto',
            'resolved'=>'Resolvido'
        ];
        $operacoes = [
            'consume'=>'Saída por consumo', 'entry'=>'Entrada', 'reserve'=>'Reserva',
            'release'=>'Liberação de reserva', 'return'=>'Devolução',
            'adjust_in'=>'Ajuste de entrada', 'adjust_out'=>'Ajuste de saída',
            'block'=>'Bloqueio', 'unblock'=>'Desbloqueio', 'discard'=>'Descarte',
            'transfer'=>'Transferência'
        ];
        $areas = [
            'users'=>'Usuários', 'medications'=>'Medicamentos', 'batches'=>'Lotes',
            'stock_movements'=>'Movimentações', 'temperature_incidents'=>'Conservação',
            'purchase_orders'=>'Pedidos', 'purchase_recommendations'=>'Sugestões de compra',
            'suppliers'=>'Fornecedores', 'supplier_products'=>'Condições de fornecimento',
            'alerts'=>'Alertas', 'integration_events'=>'Equipamentos'
        ];
        $acoes = [
            'auth.login'=>'Entrada no sistema', 'auth.logout'=>'Saída do sistema',
            'auth.password'=>'Alteração de senha', 'catalog.save'=>'Cadastro de medicamento',
            'catalog.toggle'=>'Ativação de medicamento', 'batches.create'=>'Entrada de lote',
            'stock.move'=>'Movimentação de estoque', 'purchase.approve'=>'Aprovação de compra',
            'purchase.reject'=>'Rejeição de compra', 'purchase.order'=>'Emissão de pedido'
        ];
        $linhas=[];
        foreach(self::data($tipo) as $linha){
            $formatada=[];
            foreach($linha as $chave=>$valor){
                $rotulo=$rotulos[$chave] ?? ucfirst(str_replace('_',' ',(string)$chave));
                if($valor!==null){
                    if($chave==='situacao') $valor=$situacoes[$valor]??$valor;
                    if($chave==='operacao') $valor=$operacoes[$valor]??$valor;
                    if($chave==='entidade') $valor=$areas[$valor]??$valor;
                    if($chave==='acao') $valor=$acoes[$valor]??str_replace(['.','_'],[' — ',' '],(string)$valor);
                    if($chave==='origem') $valor=$valor==='simulated'?'Medição simulada':$valor;
                    if(in_array($chave,['data','validade'],true)){
                        $instante=strtotime((string)$valor);
                        if($instante!==false) $valor=date(strlen((string)$valor)>10?'d/m/Y H:i':'d/m/Y',$instante);
                    }
                    if(in_array($chave,['preco','valor'],true))$valor='R$ '.number_format((float)$valor,2,',','.');
                    if($chave==='confiabilidade')$valor=number_format((float)$valor*100,1,',','.').'%';
                    if($chave==='temperatura')$valor=number_format((float)$valor,2,',','.').' °C';
                }
                $formatada[$rotulo]=$valor ?? '—';
            }
            $linhas[]=$formatada;
        }
        return $linhas;
    }
    public static function csv(string $type):void {
        $rows=self::dadosApresentacao($type);
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="estoquemed_'.preg_replace('/[^a-z]/','',$type).'.csv"');
        $out=fopen('php://output','w');
        fwrite($out,"\xEF\xBB\xBF");
        if($rows){
            fputcsv($out,array_keys($rows[0]),';');
            foreach($rows as $row)fputcsv($out,array_values($row),';');
        }
        fclose($out);
    }
    public static function pdf(string $type):void {
        $rows=self::dadosApresentacao($type);
        $pdf=SimplePdf::render('EstoqueMed_Mb | '.self::titulo($type),$rows);
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="estoquemed_'.preg_replace('/[^a-z]/','',$type).'.pdf"');
        header('Content-Length: '.strlen($pdf));
        echo $pdf;
    }
}
