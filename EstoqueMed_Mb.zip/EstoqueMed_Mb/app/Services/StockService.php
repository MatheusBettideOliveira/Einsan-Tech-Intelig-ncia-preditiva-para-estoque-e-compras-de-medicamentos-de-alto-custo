<?php
declare(strict_types=1);
namespace EstoqueMed\Services;
use EstoqueMed\Core\{DB,Auth,Audit,HttpException,Input};
use PDO;
final class StockService {
    public static function move(array $input):array {
        $type=Input::str($input,'type',30);
        if(!in_array($type,['entry','consume','reserve','release','adjust_in','adjust_out','block','unblock','discard','return'],true))throw new HttpException(422,'Tipo de movimentação inválido.');
        $batchId=Input::int($input,'batch_id',1);
        $qty=in_array($type,['block','unblock'],true)?0:Input::int($input,'quantity',1,100000);
        $key=Input::str($input,'event_key',100);
        $reason=Input::str($input,'reason',255);
        $user=Auth::require('stock');
        return DB::transaction(static function(PDO $pdo) use($batchId,$qty,$type,$key,$reason,$user) {
            $check=$pdo->prepare('SELECT id FROM stock_movements WHERE event_key=?');$check->execute([$key]);
            if($existing=$check->fetchColumn())return ['movement_id'=>(int)$existing,'duplicate'=>true];
            $s=$pdo->prepare('SELECT b.*,l.unit_id FROM batches b JOIN locations l ON l.id=b.location_id WHERE b.id=? FOR UPDATE');$s->execute([$batchId]);$b=$s->fetch();
            if(!$b)throw new HttpException(404,'Lote inexistente.');
            $check->execute([$key]);if($existing=$check->fetchColumn())return ['movement_id'=>(int)$existing,'duplicate'=>true];
            $status=$b['status'];$diff=0;$nextStatus=$status;
            if(in_array($type,['consume','reserve','adjust_out'],true) && ($status!=='available'||$b['expires_at']<date('Y-m-d')))throw new HttpException(422,'Lote não liberado para esta operação.');
            switch($type) {
                case 'entry':case 'return':case 'adjust_in':
                    if($b['expires_at']<date('Y-m-d')||in_array($status,['expired','discarded','blocked','quarantine'],true))throw new HttpException(422,'Lote indisponível para entrada.');
                    StorageGuard::ensure($pdo,(int)$b['location_id'],(int)$b['medication_id'],$qty);
                    $diff=$qty;$nextStatus='available';break;
                case 'consume':case 'adjust_out':
                    $reserved=(int)self::reserved($pdo,$batchId);
                    if((int)$b['quantity']-$reserved<$qty)throw new HttpException(409,'Saldo livre insuficiente.');
                    $diff=-$qty;$nextStatus=(int)$b['quantity']===$qty?'depleted':'available';break;
                case 'reserve':
                    if($b['quantity']-self::reserved($pdo,$batchId)<$qty)throw new HttpException(409,'Saldo livre insuficiente para reserva.');
                    $pdo->prepare('INSERT INTO stock_reservations(batch_id,quantity,reason,created_by) VALUES(?,?,?,?)')->execute([$batchId,$qty,$reason,$user['id']]);break;
                case 'release':
                    $reserve=self::reserved($pdo,$batchId);
                    if($reserve<$qty)throw new HttpException(409,'Reserva insuficiente.');
                    $remaining=$qty;
                    $list=$pdo->prepare('SELECT id,quantity FROM stock_reservations WHERE batch_id=? AND active=1 ORDER BY id FOR UPDATE');$list->execute([$batchId]);
                    foreach($list as $res){$use=min($remaining,(int)$res['quantity']); if($use===(int)$res['quantity'])$pdo->prepare('UPDATE stock_reservations SET active=0 WHERE id=?')->execute([$res['id']]);else $pdo->prepare('UPDATE stock_reservations SET quantity=quantity-? WHERE id=?')->execute([$use,$res['id']]);$remaining-=$use;if(!$remaining)break;}
                    break;
                case 'block':
                    if(in_array($status,['expired','discarded','depleted'],true))throw new HttpException(422,'Lote não elegível para bloqueio.');
                    $nextStatus='blocked';break;
                case 'unblock':
                    if(!in_array($status,['blocked','quarantine'],true))throw new HttpException(422,'Lote não está bloqueado.');
                    if($b['expires_at']<date('Y-m-d'))throw new HttpException(422,'Lote vencido não pode ser liberado.');
                    $nextStatus='available';break;
                case 'discard':
                    if((int)$b['quantity']-self::reserved($pdo,$batchId)<$qty)throw new HttpException(409,'Saldo livre insuficiente para descarte.');
                    $diff=-$qty;$nextStatus=(int)$b['quantity']===$qty?'discarded':$status;break;
            }
            if($diff && $b['quantity']+$diff<0)throw new HttpException(409,'Estoque negativo não permitido.');
            $pdo->prepare('UPDATE batches SET quantity=quantity+?,status=? WHERE id=?')->execute([$diff,$nextStatus,$batchId]);
            $pdo->prepare('INSERT INTO stock_movements(event_key,batch_id,medication_id,movement_type,quantity,source_location_id,reason,user_id) VALUES(?,?,?,?,?,?,?,?)')->execute([$key,$batchId,$b['medication_id'],$type,$qty,$b['location_id'],$reason,$user['id']]);
            $moveId=(int)$pdo->lastInsertId();
            if($type==='consume'){
                $pdo->prepare("INSERT INTO consumption_history(medication_id,unit_id,consumed_on,quantity,source) VALUES(?,?,CURDATE(),?,'movement') ON DUPLICATE KEY UPDATE quantity=quantity+VALUES(quantity)")->execute([$b['medication_id'],$b['unit_id'],$qty]);
            }
            Audit::log('stock.'.$type,'batches',(string)$batchId,['quantity'=>$qty,'movement_id'=>$moveId]);
            return ['movement_id'=>$moveId,'duplicate'=>false,'batch_id'=>$batchId,'new_quantity'=>(int)$b['quantity']+$diff,'status'=>$nextStatus];
        });
    }
    private static function reserved(PDO $pdo,int $batch):int{$s=$pdo->prepare('SELECT COALESCE(SUM(quantity),0) FROM stock_reservations WHERE batch_id=? AND active=1');$s->execute([$batch]);return (int)$s->fetchColumn();}
    public static function fefo(int $med,int $qty):array {
        $lots=DB::all("SELECT b.id,b.lot_number,b.expires_at,b.quantity-COALESCE((SELECT SUM(r.quantity) FROM stock_reservations r WHERE r.batch_id=b.id AND r.active=1),0) usable FROM batches b WHERE b.medication_id=? AND b.status='available' AND b.expires_at>=CURDATE() AND b.quantity>0 ORDER BY b.expires_at,b.id",[$med]);
        $alloc=[];$left=$qty;
        foreach($lots as $b){$take=min($left,max(0,(int)$b['usable']));if($take>0)$alloc[]=['batch_id'=>(int)$b['id'],'lot'=>$b['lot_number'],'expires_at'=>$b['expires_at'],'quantity'=>$take];$left-=$take;if(!$left)break;}
        return ['allocation'=>$alloc,'remaining'=>$left,'feasible'=>$left===0];
    }
    public static function transfer(array $v):array {
        $batch=Input::int($v,'batch_id',1);$target=Input::int($v,'target_location_id',1);$key=Input::str($v,'event_key',100);$reason=Input::str($v,'reason',255);
        return DB::transaction(static function(PDO $p)use($batch,$target,$key,$reason){
            $s=$p->prepare('SELECT b.*,m.temp_min,m.temp_max FROM batches b JOIN medications m ON m.id=b.medication_id WHERE b.id=? FOR UPDATE');$s->execute([$batch]);$b=$s->fetch();if(!$b)throw new HttpException(404,'Lote não localizado.');
            $s=$p->prepare('SELECT id FROM stock_movements WHERE event_key=?');$s->execute([$key]);if($row=$s->fetch())return ['duplicate'=>true,'movement_id'=>$row['id']];
            if($b['status']!=='available'||$b['expires_at']<date('Y-m-d')||self::reserved($p,$batch)>0)throw new HttpException(422,'Transferência exige lote liberado, válido e sem reservas.');
            if($target===(int)$b['location_id'])throw new HttpException(422,'Destino idêntico à origem.');
            StorageGuard::ensure($p,$target,(int)$b['medication_id'],(int)$b['quantity']);
            $p->prepare('UPDATE batches SET location_id=? WHERE id=?')->execute([$target,$batch]);
            $p->prepare("INSERT INTO stock_movements(event_key,batch_id,medication_id,movement_type,quantity,source_location_id,target_location_id,reason,user_id) VALUES(?,?,?,'transfer',?,?,?,?,?)")->execute([$key,$batch,$b['medication_id'],$b['quantity'],$b['location_id'],$target,$reason,Auth::user()['id']]);
            $id=(int)$p->lastInsertId();Audit::log('stock.transfer','batches',(string)$batch,['target'=>$target,'movement'=>$id]);return ['movement_id'=>$id,'transferred_quantity'=>(int)$b['quantity'],'duplicate'=>false];
        });
    }
    public static function reverse(array $v):array {
        $origId=Input::int($v,'movement_id',1);$reason=Input::str($v,'reason',255);$key=Input::str($v,'event_key',100);
        return DB::transaction(static function(PDO $p) use($origId,$reason,$key){
            $s=$p->prepare('SELECT * FROM stock_movements WHERE id=? FOR UPDATE');$s->execute([$origId]);$orig=$s->fetch();if(!$orig||!in_array($orig['movement_type'],['entry','consume'],true))throw new HttpException(422,'Estorno disponível somente para entrada ou consumo.');
            $s=$p->prepare("SELECT id FROM stock_movements WHERE related_entity='reversal' AND related_id=?");$s->execute([(string)$origId]);if($record=$s->fetch())return ['duplicate'=>true,'movement_id'=>$record['id']];
            $s=$p->prepare('SELECT * FROM batches WHERE id=? FOR UPDATE');$s->execute([$orig['batch_id']]);$b=$s->fetch();if(!$b)throw new HttpException(404,'Lote não encontrado.');
            $qty=(int)$orig['quantity'];$isConsumption=$orig['movement_type']==='consume';
            if(!$isConsumption && ((int)$b['quantity']-self::reserved($p,(int)$b['id'])<$qty||$b['status']!=='available'))throw new HttpException(409,'Não há saldo liberado suficiente para estornar a entrada.');
            $delta=$isConsumption?$qty:-$qty;
            $newStatus=$isConsumption?($b['expires_at']<date('Y-m-d')?'quarantine':($b['status']==='depleted'?'available':$b['status'])):((int)$b['quantity']===$qty?'depleted':$b['status']);
            $p->prepare('UPDATE batches SET quantity=quantity+?,status=? WHERE id=?')->execute([$delta,$newStatus,$b['id']]);
            if($isConsumption){
                $loc=$p->prepare('SELECT unit_id FROM locations WHERE id=?');$loc->execute([$orig['source_location_id']]);$unit=(int)$loc->fetchColumn();
                $date=substr($orig['created_at'],0,10);
                $s=$p->prepare("SELECT id,quantity FROM consumption_history WHERE medication_id=? AND unit_id=? AND consumed_on=? AND source='movement' FOR UPDATE");$s->execute([$orig['medication_id'],$unit,$date]);$r=$s->fetch();
                if(!$r||(int)$r['quantity']<$qty)throw new HttpException(409,'Histórico de consumo insuficiente para estorno.');
                $p->prepare('UPDATE consumption_history SET quantity=quantity-? WHERE id=?')->execute([$qty,$r['id']]);
            }
            $p->prepare("INSERT INTO stock_movements(event_key,batch_id,medication_id,movement_type,quantity,source_location_id,reason,user_id,related_entity,related_id) VALUES(?,?,?,'reversal',?,?,?,?, 'reversal',?)")->execute([$key,$orig['batch_id'],$orig['medication_id'],$qty,$orig['source_location_id'],$reason,Auth::user()['id'],(string)$origId]);
            $mid=(int)$p->lastInsertId();Audit::log('stock.reversal','stock_movements',(string)$origId,['new_movement'=>$mid]);return ['movement_id'=>$mid,'duplicate'=>false];
        });
    }
    public static function temperatureEvent(array $v):array {
        $id=Input::int($v,'device_id',1);$type=Input::str($v,'type',40);$key=Input::str($v,'event_key',100);
        if(!in_array($type,['open','close','temperature','recovered','communication_failure','barcode_failure'],true))throw new HttpException(422,'Evento inválido.');
        $temp=isset($v['temperature'])?Input::num($v,'temperature',-40,80):null;
        return DB::transaction(static function(PDO $p)use($id,$type,$temp,$key,$v){
            $s=$p->prepare('SELECT * FROM devices WHERE id=? FOR UPDATE');$s->execute([$id]);$dev=$s->fetch();if(!$dev)throw new HttpException(404,'Equipamento inexistente.');
            $s=$p->prepare('SELECT id FROM integration_events WHERE event_key=?');$s->execute([$key]);if($row=$s->fetch())return ['duplicate'=>true,'event_id'=>(int)$row['id']];
            $p->prepare('INSERT INTO integration_events(event_key,device_id,event_type,payload) VALUES(?,?,?,?)')->execute([$key,$id,$type,json_encode($v,JSON_UNESCAPED_UNICODE)]);
            $eventId=(int)$p->lastInsertId();
            $status=$dev['status'];$door=(int)$dev['door_open'];$temperature=$temp??(float)$dev['temperature'];
            if($type==='open')$door=1;if($type==='close')$door=0;
            if($type==='communication_failure')$status='communication_failure';
            if($type==='recovered')$status='normal';
            if($type==='temperature'||$type==='recovered'){
                $p->prepare("INSERT INTO temperature_readings(device_id,temperature,recorded_at,source) VALUES(?,?,NOW(),'simulated')")->execute([$id,$temperature]);
                $s=$p->prepare("SELECT DISTINCT m.temp_min,m.temp_max FROM batches b JOIN locations l ON l.id=b.location_id JOIN medications m ON m.id=b.medication_id WHERE l.device_id=? AND b.quantity>0 AND b.status='available'");$s->execute([$id]);
                $excursion=false;foreach($s->fetchAll() as $limits)if($temperature<(float)$limits['temp_min']||$temperature>(float)$limits['temp_max']){$excursion=true;break;}
                if($excursion){
                    $status='excursion';
                    $p->prepare('INSERT INTO temperature_incidents(device_id,temperature,description) VALUES(?,?,?)')->execute([$id,$temperature,'Excursão simulada: avaliação do responsável técnico necessária']);
                    $p->prepare("UPDATE batches b JOIN locations l ON l.id=b.location_id JOIN medications m ON m.id=b.medication_id SET b.status='quarantine' WHERE l.device_id=? AND b.status='available' AND b.quantity>0 AND (? < m.temp_min OR ? > m.temp_max)")->execute([$id,$temperature,$temperature]);
                    $p->prepare("INSERT INTO alerts(dedupe_key,level,type,description,entity_type,entity_id) VALUES(?, 'critical','temperature',?,'devices',?) ON DUPLICATE KEY UPDATE is_read=0,status='open',description=VALUES(description)")->execute(['temp-'.$eventId,'Excursão simulada no equipamento '.$dev['name'].'; lotes potencialmente afetados isolados.',$id]);
                }
            }
            $p->prepare('UPDATE devices SET temperature=?,door_open=?,status=?,last_sync=NOW() WHERE id=?')->execute([$temperature,$door,$status,$id]);
            Audit::log('device.'.$type,'devices',(string)$id,['temperature'=>$temperature]);
            return ['duplicate'=>false,'event_id'=>$eventId,'status'=>$status,'temperature'=>$temperature,'door_open'=>$door,'simulated'=>true];
        });
    }
}
