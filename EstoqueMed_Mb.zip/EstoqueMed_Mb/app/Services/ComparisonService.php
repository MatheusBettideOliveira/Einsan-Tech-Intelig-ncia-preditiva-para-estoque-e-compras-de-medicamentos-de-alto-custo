<?php
declare(strict_types=1);
namespace EstoqueMed\Services;
use EstoqueMed\Core\DB;
use EstoqueMed\Core\HttpException;

 
final class ComparisonService {
    public static function compare(int $med,int $days=60):array {
        if(!in_array($days,[30,60,90],true))throw new HttpException(422,'Horizonte 30, 60 ou 90.');
        $m=DB::one('SELECT * FROM medications WHERE id=?',[$med]);if(!$m)throw new HttpException(404,'Medicamento inexistente.');
        $history=AnalyticsService::history($med)['series'];
        if(!$history)throw new HttpException(422,'Histórico insuficiente.');
        $demand=[];for($i=0;$i<$days;$i++)$demand[]=(int)$history[($i+count($history)-min(count($history),$days))%count($history)];
        $lots=DB::all("SELECT quantity,expires_at,unit_cost FROM batches WHERE medication_id=? AND status='available' AND quantity>0 ORDER BY expires_at",[$med]);
        $dailyAvg=array_sum($demand)/max(1,count($demand));
        $initialQty=array_sum(array_map(static fn($x)=>(int)$x['quantity'],$lots));
        $offers=DecisionEngine::suppliers($med,1,$dailyAvg,$initialQty,max(1,(float)$m['reference_price']*.35));if(!$offers)throw new HttpException(422,'Cadastre ofertas de fornecedores.');
        $traditional=self::run('traditional',$demand,$lots,$offers,$m);
        $smart=self::run('smart',$demand,$lots,$offers,$m);
        return ['medication'=>['id'=>$med,'name'=>$m['name']],'days'=>$days,'same_demand'=>true,'total_demand'=>array_sum($demand),'traditional'=>$traditional,'smart'=>$smart,'net_saving'=>round($traditional['total_cost']-$smart['total_cost'],2),'definition'=>'Custos hipotéticos de aquisição, frete, vencimento, guarda e falta; simulação determinística, não economia realizada.'];
    }
    private static function run(string $policy,array $demand,array $seedLots,array $offers,array $m):array {
        $lots=array_map(static fn($b)=>['qty'=>(int)$b['quantity'],'expires'=>$b['expires_at'],'cost'=>(float)$b['unit_cost']],$seedLots);
        $today=new \DateTimeImmutable('today');$incoming=[];$purchased=0.;$freight=0.;$lost=0;$expiredCost=0.;$holdingCost=0.;$orders=0;$capital=0.;$stockSeries=[];$served=0;
        $ref=(float)$m['reference_price'];$dailyMean=array_sum($demand)/max(1,count($demand));
        $min=(int)$m['min_stock'];$safety=(int)$m['safety_stock'];$max=(int)$m['max_stock'];
        foreach($demand as $day=>$need){
            $date=$today->modify('+' . $day . ' days')->format('Y-m-d');
            foreach($lots as &$b){if($b['qty']>0&&$b['expires']<$date){$expiredCost+=$b['qty']*$b['cost'];$b['qty']=0;}}unset($b);
            foreach($incoming as $k=>$shipment)if($shipment['arrives']===$day){$lots[]=['qty'=>$shipment['qty'],'expires'=>$today->modify('+'.($day+180).' days')->format('Y-m-d'),'cost'=>$shipment['price']];unset($incoming[$k]);}
            usort($lots,static fn($a,$b)=>strcmp($a['expires'],$b['expires']));
            $qty=array_sum(array_column($lots,'qty'));
            $outstanding=array_sum(array_column($incoming,'qty'));
            $sortedByPrice=$offers;usort($sortedByPrice,static fn($a,$b)=>[$a['unit_price'],$a['supplier_id']]<=>[$b['unit_price'],$b['supplier_id']]);$standard=$sortedByPrice[0];  
            $best=$offers[0];  
            if($policy==='traditional'){$trigger=$min;$target=$max;$choice=$standard;}
            else {$choice=$best;$trigger=(int)ceil($dailyMean*$choice['lead_days']+$safety);$target=min($max,(int)ceil($dailyMean*($choice['lead_days']+7)+$safety));}
            if($qty+$outstanding<=$trigger){
                $needed=max(0,$target-$qty-$outstanding);
                $multiple=$choice['pack_multiple'];$orderQty=(int)ceil(max($needed,$choice['min_order'])/max(1,$multiple))*max(1,$multiple);
                $space=max(0,$max-$qty-$outstanding);
                if($orderQty>$space)$orderQty=0;  
                if($orderQty>0){$incoming[]=['arrives'=>$day+$choice['lead_days'],'qty'=>$orderQty,'price'=>$choice['unit_price']];$purchased+=$orderQty*$choice['unit_price'];$freight+=$choice['freight'];$orders++;}
            }
            $remaining=$need;
            foreach($lots as &$lot){$taken=min($remaining,$lot['qty']);$lot['qty']-=$taken;$remaining-=$taken;if(!$remaining)break;}unset($lot);
            $lost+=$remaining;$served+=$need-$remaining;
            $value=0.;$qty=0;foreach($lots as $lot){$value+=$lot['qty']*$lot['cost'];$qty+=$lot['qty'];}
            $capital+=$value;$holdingCost+=$value*.00025;  
            $stockSeries[]=['day'=>$day+1,'stock'=>$qty,'unserved'=>$remaining];
        }
        $shortageCost=$lost*$ref*.35;
        $total=$purchased+$freight+$expiredCost+$holdingCost+$shortageCost;
        return ['policy'=>$policy,'total_cost'=>round($total,2),'purchases_cost'=>round($purchased,2),'freight'=>round($freight,2),'expired_loss'=>round($expiredCost,2),'holding_cost'=>round($holdingCost,2),'shortage_penalty'=>round($shortageCost,2),'unserved'=>$lost,'service_rate'=>round(100*$served/max(1,array_sum($demand)),2),'orders'=>$orders,'avg_capital'=>round($capital/max(1,count($demand)),2),'stock_series'=>$stockSeries];
    }
}
