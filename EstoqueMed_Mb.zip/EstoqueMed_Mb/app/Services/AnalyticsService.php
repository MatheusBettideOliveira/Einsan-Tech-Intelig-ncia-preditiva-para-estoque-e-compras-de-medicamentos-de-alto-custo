<?php
declare(strict_types=1);
namespace EstoqueMed\Services;
use EstoqueMed\Core\DB;
use EstoqueMed\Core\HttpException;
use EstoqueMed\Algorithms\ForecastEngine;

final class AnalyticsService {
    public static function history(int $med,int $days=180):array {
        $rows=DB::all('SELECT consumed_on,SUM(quantity) qty FROM consumption_history WHERE medication_id=? AND consumed_on>=DATE_SUB(CURDATE(),INTERVAL ? DAY) GROUP BY consumed_on ORDER BY consumed_on',[$med,$days]);
        $map=array_column($rows,'qty','consumed_on');$series=[];$labels=[];
        $today=new \DateTimeImmutable('today');
        for($i=$days-1;$i>=0;$i--) { $date=$today->modify("-$i days")->format('Y-m-d');$labels[]=$date;$series[]=(int)($map[$date]??0); }
         
        if(!$rows)return ['dates'=>[],'series'=>[]];
        $first=$rows[0]['consumed_on'];
        while($labels && $labels[0]<$first){array_shift($labels);array_shift($series);}
        return ['dates'=>$labels,'series'=>$series];
    }
    public static function forecast(int $med,int $days=30):array {
        if(!in_array($days,[7,15,30,60,90],true))throw new HttpException(422,'Horizonte inválido.');
        $medication=DB::one('SELECT id,code,name FROM medications WHERE id=? AND active=1',[$med]);
        if(!$medication)throw new HttpException(404,'Medicamento não encontrado.');
        $history=self::history($med);
        return ['medication'=>$medication,'dates'=>$history['dates'],'forecast'=>ForecastEngine::predict($history['series'],$days)];
    }
    public static function dashboard(int $days=30):array {
        $row=DB::one("SELECT COUNT(DISTINCT m.id) medications,COALESCE(SUM(CASE WHEN b.status='available' AND b.expires_at>=CURDATE() THEN b.quantity ELSE 0 END),0) units,COUNT(b.id) batches,COALESCE(SUM(CASE WHEN b.status NOT IN ('discarded','depleted') AND b.quantity>0 THEN b.quantity*b.unit_cost ELSE 0 END),0) inventory_value,COALESCE(SUM(CASE WHEN b.expires_at BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY) AND b.status IN ('available','reserved') THEN b.quantity*b.unit_cost ELSE 0 END),0) expiry_exposure,SUM(CASE WHEN b.expires_at BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY) AND b.quantity>0 THEN 1 ELSE 0 END) expiring_batches FROM medications m LEFT JOIN batches b ON m.id=b.medication_id WHERE m.active=1");
        $medications=DB::all('SELECT id,name,min_stock,max_stock,safety_stock,reference_price FROM medications WHERE active=1 ORDER BY name');
        $risks=[];$excess=[];$suggested=[];$coverage=[];$consumption=0;
        foreach($medications as $m){
            $id=(int)$m['id'];$q=(int)DB::scalar("SELECT COALESCE(SUM(quantity),0) FROM batches WHERE medication_id=? AND status='available' AND expires_at>=CURDATE()",[$id]);
            $h=self::history($id);$forecast=ForecastEngine::predict($h['series'],$days);$d=$forecast['daily'];$consumption+=$d;
            if($d>0)$coverage[]=$q/$d;
            if($q<max((int)$m['min_stock'],ceil($d*7)))$risks[]=['id'=>$id,'name'=>$m['name'],'available'=>$q,'daily'=>$d];
            if($q>(int)$m['max_stock'])$excess[]=['id'=>$id,'name'=>$m['name'],'available'=>$q];
            $replenishment=DecisionEngine::recommendation($id);
            if($replenishment['needed']>0)$suggested[]=['id'=>$id,'name'=>$m['name'],'quantity'=>$replenishment['quantity'],'value'=>$replenishment['estimated_cost'],'feasible'=>$replenishment['feasible']];
        }
        $lowAlerts=(int)DB::scalar("SELECT COUNT(*) FROM alerts WHERE status='open'");
        $temperature=(int)DB::scalar("SELECT COUNT(*) FROM temperature_incidents WHERE status='open'");
        $evolution=DB::all('SELECT consumed_on,SUM(quantity) quantity FROM consumption_history WHERE consumed_on>=DATE_SUB(CURDATE(),INTERVAL 60 DAY) GROUP BY consumed_on ORDER BY consumed_on');
        $purchases=DB::all('SELECT s.name,COUNT(p.id) orders,COALESCE(SUM(i.quantity*i.unit_price),0) total FROM suppliers s LEFT JOIN purchase_orders p ON p.supplier_id=s.id LEFT JOIN purchase_order_items i ON i.order_id=p.id GROUP BY s.id,s.name ORDER BY total DESC');
        $value=round((float)$row['inventory_value'],2);
        return ['kpis'=>['inventory_value'=>$value,'capital_tied'=>$value,'medications'=>(int)$row['medications'],'units'=>(int)$row['units'],'batches'=>(int)$row['batches'],'expiry_exposure'=>round((float)$row['expiry_exposure'],2),'expiring_batches'=>(int)$row['expiring_batches'],'stockout_risk'=>count($risks),'excess_stock'=>count($excess),'suggested_purchases'=>count($suggested),'suggested_cost'=>round(array_sum(array_column($suggested,'value')),2),'daily_consumption'=>round($consumption,2),'avg_coverage_days'=>count($coverage)?round(array_sum($coverage)/count($coverage),1):null,'temperature_incidents'=>$temperature,'open_alerts'=>$lowAlerts,'proven_savings'=>null], 'risks'=>$risks,'excess'=>$excess,'suggested'=>$suggested,'consumption_evolution'=>$evolution,'purchases_by_supplier'=>$purchases,'period_days'=>$days];
    }
}
