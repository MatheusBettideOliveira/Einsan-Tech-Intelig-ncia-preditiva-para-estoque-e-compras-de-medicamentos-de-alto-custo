<?php
declare(strict_types=1);
namespace EstoqueMed\Services;
use EstoqueMed\Core\DB;
use EstoqueMed\Core\HttpException;

final class DecisionEngine {
    public static function stock(int $med):array {
        $available=(int)DB::scalar("SELECT COALESCE(SUM(quantity),0) FROM batches WHERE medication_id=? AND status='available' AND expires_at>=CURDATE()",[$med]);
        $reserved=(int)DB::scalar("SELECT COALESCE(SUM(r.quantity),0) FROM stock_reservations r JOIN batches b ON b.id=r.batch_id WHERE b.medication_id=? AND r.active=1",[$med]);
        $incoming=(int)DB::scalar("SELECT COALESCE(SUM(i.quantity-i.received_quantity),0) FROM purchase_order_items i JOIN purchase_orders o ON o.id=i.order_id WHERE i.medication_id=? AND o.status IN ('issued','partially_received')",[$med]);
        $expiring=(int)DB::scalar("SELECT COALESCE(SUM(quantity),0) FROM batches WHERE medication_id=? AND status='available' AND expires_at BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY)",[$med]);
        return ['available'=>max(0,$available-$reserved),'on_hand'=>$available,'reserved'=>$reserved,'incoming'=>$incoming,'expiring_30d'=>$expiring];
    }
    public static function suppliers(int $med,int $quantity=1,float $daily=0,float $onHand=0,float $penaltyPerUnit=0):array {
        $offers=DB::all('SELECT sp.*,s.name,s.reliability FROM supplier_products sp JOIN suppliers s ON s.id=sp.supplier_id WHERE sp.medication_id=? AND s.active=1 AND (sp.valid_until IS NULL OR sp.valid_until>=CURDATE()) ORDER BY s.id',[$med]);
        $candidates=[];
        foreach($offers as $sp){
            $multiple=max(1,(int)$sp['pack_multiple']);$units=(int)ceil(max($quantity,(int)$sp['min_order'])/$multiple)*$multiple;
            $lead=(int)$sp['lead_days'];$lack=max(0,ceil($daily*$lead-$onHand));
            $risk=$lack*$penaltyPerUnit + (1-(float)$sp['reliability'])*$daily*$lead*$penaltyPerUnit;
            $cost=$units*(float)$sp['unit_price']+(float)$sp['freight'];
            $candidates[]=['supplier_id'=>(int)$sp['supplier_id'],'supplier'=>$sp['name'],'quantity'=>$units,'unit_price'=>(float)$sp['unit_price'],'freight'=>(float)$sp['freight'],'lead_days'=>$lead,'min_order'=>(int)$sp['min_order'],'pack_multiple'=>$multiple,'reliability'=>(float)$sp['reliability'],'purchase_cost'=>round($cost,2),'shortage_penalty'=>round($risk,2),'score'=>round($cost+$risk,2)];
        }
        usort($candidates,static fn($a,$b)=>[$a['score'],$a['supplier_id']]<=>[$b['score'],$b['supplier_id']]);
        return $candidates;
    }
    public static function recommendation(int $id,array $overrides=[]):array {
        $m=DB::one('SELECT * FROM medications WHERE id=? AND active=1',[$id]);
        if(!$m)throw new HttpException(404,'Medicamento não encontrado.');
        $period=(int)($overrides['horizon']??30);
        if(!in_array($period,[7,15,30,60,90],true))$period=30;
        $f=AnalyticsService::forecast($id,$period)['forecast'];
        $stock=self::stock($id);
        $daily=max(0,(float)($overrides['daily']??$f['daily'])*(1+(float)($overrides['growth_pct']??0)/100));
        $safety=max(0,(int)($overrides['safety_stock']??$m['safety_stock']));
        $review=max(1,(int)($overrides['purchase_frequency']??7));
        $validityDays=max(1,(int)($overrides['validity_days']??365));
        $leadVariation=max(0,(int)($overrides['lead_variation']??0));
        $unavailable=max(0,min(100,(float)($overrides['unavailable_pct']??0)));
        $capacity=max(0,(int)($overrides['capacity']??$m['max_stock']));
        $budget=max(0,(float)($overrides['budget']??1e10));
        $tempFault=(bool)($overrides['temperature_fault']??false);
        $available=$tempFault?0:(int)floor($stock['available']*(100-$unavailable)/100);
        $effective=max(0,$available+$stock['incoming']);
        $mae=$f['metrics'][$f['model']]['mae']??null;
        $locations=DB::all('SELECT l.capacity,COALESCE(SUM(b.quantity),0) used_quantity FROM locations l LEFT JOIN batches b ON b.location_id=l.id GROUP BY l.id,l.capacity');
        $physicalSpace=(int)array_sum(array_map(static fn($l)=>max(0,(int)$l['capacity']-(int)$l['used_quantity']),$locations));
        $maxQty=max(0,min($capacity-$effective,$physicalSpace));
        $expiryLimit=max(0,(int)ceil($daily*min($period,$validityDays)+$safety-$effective));
        $penalty=max(1,(float)$m['reference_price']*.35);
        $rawOffers=self::suppliers($id,1,$daily,$available,$penalty);
         
        $defaultLead=$rawOffers?min(array_column($rawOffers,'lead_days')):7;
        $lead=max(1,min(90,(int)($overrides['lead_days']??$defaultLead)+$leadVariation));
        $calc=static function(int $lead)use($daily,$review,$safety,$mae,$effective):array {
             
            $variation=$mae===null?0:1.28*(float)$mae*sqrt($lead+$review);
            $target=(int)ceil($daily*($lead+$review)+$safety+$variation);
            return ['target'=>$target,'needed'=>max(0,$target-$effective),'variation'=>$variation];
        };
        $baseline=$calc($lead);
        $candidates=[];
        foreach($rawOffers as $offer){
            $supplierLead=max(1,min(90,(int)($overrides['lead_days']??$offer['lead_days'])+$leadVariation));
            $plan=$calc($supplierLead);
            $multiple=max(1,(int)$offer['pack_multiple']);
            $wanted=max($plan['needed'],(int)$offer['min_order']);
            $quantity=(int)ceil($wanted/$multiple)*$multiple;
            $price=(float)($overrides['unit_price']??$offer['unit_price']);
            $cost=round($quantity*$price+(float)$offer['freight'],2);
            $short=max(0,ceil($daily*$supplierLead-$available));
            $risk=round(($short + (1-(float)$offer['reliability'])*$daily*$supplierLead)*$penalty,2);
            $offer['quantity']=$quantity;
            $offer['unit_price']=$price;
            $offer['lead_days']=$supplierLead;
            $offer['purchase_cost']=$cost;
            $offer['shortage_penalty']=$risk;
            $offer['score']=round($cost+$risk,2);
            $offer['target']=$plan['target'];
            $offer['needed']=$plan['needed'];
            $offer['variability_buffer']=round($plan['variation'],2);
            $offer['feasible']=$plan['needed']>0 && $quantity<=$maxQty && $quantity<=$expiryLimit && $cost<=$budget;
            $candidates[]=$offer;
        }
        usort($candidates,static fn($a,$b)=>[$a['score'],$a['supplier_id']]<=>[$b['score'],$b['supplier_id']]);
        $feasible=array_values(array_filter($candidates,static fn($x)=>$x['feasible']));
        $winner=$baseline['needed']>0?($feasible[0]??null):null;
        $quantity=$winner['quantity']??0;
        $target=$winner['target']??$baseline['target'];
        $needed=$winner['needed']??$baseline['needed'];
        $variation=$winner['variability_buffer']??$baseline['variation'];
        $lead=$winner['lead_days']??$lead;
        $riskDays=$daily>0?round($available/$daily,1):null;
        $priority=$riskDays!==null&&$riskDays<=$lead?'critical':($riskDays!==null&&$riskDays<=$lead+7?'warning':'normal');
        $explanation='Saldo livre: '.$available.' un.; reservas: '.$stock['reserved'].'; pedidos pendentes: '.$stock['incoming'].'; consumo: '.round($daily,2).' un./dia; prazo: '.$lead.' dias + revisão de '.$review.' dias; segurança: '.$safety.' un.; margem exploratória: '.round($variation,1).' un.; alvo: '.$target.' un.; necessidade: '.$needed.' un.';
        $explanation.=$winner?' Fornecedor recomendado: '.$winner['supplier'].'; comprar '.$quantity.' un. pelo custo estimado de R$ '.number_format($winner['purchase_cost'],2,',','.').'. A ordem depende de aprovação humana.':($needed===0?' Nenhuma compra necessária no horizonte-base.':' Nenhuma alternativa atende simultaneamente capacidade, orçamento, validade e embalagens; exige revisão humana.');
        if($tempFault)$explanation.=' SIMULAÇÃO: saldo potencialmente afetado por temperatura foi isolado, sem conclusão clínica sobre aproveitamento.';
        return ['medication'=>['id'=>$id,'code'=>$m['code'],'name'=>$m['name']],'forecast'=>$f,'stock'=>$stock,'daily'=>$daily,'coverage_days'=>$riskDays,'lead_days'=>$lead,'target'=>$target,'needed'=>$needed,'quantity'=>$quantity,'supplier'=>$winner,'offers'=>$candidates,'priority'=>$priority,'estimated_cost'=>$winner['purchase_cost']??0,'explanation'=>$explanation,'feasible'=>$winner!==null||$needed===0,'assumptions'=>['review_days'=>$review,'safety_stock'=>$safety,'variability_buffer'=>round($variation,2),'capacity'=>$capacity,'budget'=>$budget,'expiry_limit'=>$expiryLimit,'temperature_fault'=>$tempFault,'unavailable_pct'=>$unavailable,'validity_days'=>$validityDays,'physical_free_capacity'=>$physicalSpace,'lead_variation_days'=>$leadVariation,'penalty_per_unserved_unit'=>$penalty,'optimization_method'=>'Enumeração determinística de ofertas com restrições (heurística de fornecedor único)']];
    }
    public static function scenario(int $med,array $input):array {
        $r=self::recommendation($med,$input);
        $h=(int)($input['horizon']??30);$h=in_array($h,[7,15,30,60,90],true)?$h:30;
        $expected=$r['daily']*$h;$total=$r['stock']['available']+$r['stock']['incoming']+$r['quantity'];
        $unserved=max(0,$expected-$total);
        $r['scenario']=['horizon'=>$h,'projected_demand'=>round($expected,2),'projected_remaining'=>round(max(0,$total-$expected),2),'potential_shortage'=>round($unserved,2),'purchase_cost'=>$r['estimated_cost'],'not_guaranteed'=>true];
        return $r;
    }
}
