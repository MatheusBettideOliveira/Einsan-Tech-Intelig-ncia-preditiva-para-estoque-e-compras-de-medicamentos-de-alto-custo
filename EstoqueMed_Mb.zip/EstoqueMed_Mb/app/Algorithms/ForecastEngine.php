<?php
declare(strict_types=1);
namespace EstoqueMed\Algorithms;

 
final class ForecastEngine {
    public static function predict(array $series,int $horizon=30):array {
        $series=array_values(array_map(static fn($v)=>max(0,(float)$v),$series));
        $n=count($series);
        if(!$n) return ['model'=>'insufficient','daily'=>0,'horizon'=>$horizon,'total'=>0,'confidence'=>'Dados inexistentes','metrics'=>[],'observations'=>0,'validation_days'=>0,'band'=>null];
        $models=['naive','moving_average','weighted_average','exponential','croston_sba'];
        $eval=[];
        $validation=$n>=30?min(30,max(7,(int)floor($n*.2))):($n>=21?5:0);
        foreach($models as $model) {
            $abs=0.;$signed=0.;$denom=0.;$errors=[];
            if($validation>0) for($i=$n-$validation;$i<$n;$i++) {
                $pred=self::one(array_slice($series,0,$i),$model);
                $err=$pred-$series[$i];
                $abs+=abs($err);$signed+=$err;$denom+=$series[$i];$errors[]=$err;
            }
            $eval[$model]=['mae'=>$validation?round($abs/$validation,4):null,'wape'=>$validation&&$denom>0?round($abs/$denom*100,2):null,'bias'=>$validation?round($signed/$validation,4):null,'n'=>$validation];
        }
        $selected='moving_average';
        if($validation) { $best=INF; foreach($models as $model) if(($eval[$model]['mae']??INF)<$best) {$best=$eval[$model]['mae'];$selected=$model;} }
         
        $daily=$n<14?array_sum($series)/$n:self::one($series,$selected);
        $daily=max(0,$daily);
        $mae=$eval[$selected]['mae']??null;
        $band=$mae===null?null:['lower'=>round(max(0,($daily-1.64*$mae))*$horizon,1),'upper'=>round(($daily+1.64*$mae)*$horizon,1),'kind'=>'Faixa exploratória baseada no erro absoluto; não é intervalo de confiança calibrado'];
        $confidence=$n<30?'Histórico insuficiente para alta confiança':($mae!==null&&$daily>0&&$mae/$daily<.4?'Moderada — validar com dados operacionais':'Baixa — alta variabilidade');
        return ['model'=>$selected,'daily'=>round($daily,4),'horizon'=>$horizon,'total'=>round($daily*$horizon,2),'confidence'=>$confidence,'metrics'=>$eval,'observations'=>$n,'validation_days'=>$validation,'band'=>$band,'history'=>array_slice($series,-90)];
    }
    public static function one(array $s,string $model):float {
        $n=count($s); if(!$n)return 0.;
        switch($model) {
            case 'naive': return max(0,(float)$s[$n-1]);
            case 'moving_average': $v=array_slice($s,-14); return array_sum($v)/count($v);
            case 'weighted_average': $v=array_slice($s,-14);$sum=0.;$total=0.;foreach($v as $i=>$x){$w=$i+1;$sum+=$w*$x;$total+=$w;}return $sum/$total;
            case 'exponential':$f=(float)$s[0];for($i=1;$i<$n;$i++)$f=.3*(float)$s[$i]+.7*$f;return max(0,$f);
            case 'croston_sba':
                $positives=0;foreach($s as $v)if($v>0)$positives++;
                if($positives===0)return 0.;
                $first=null;foreach($s as $i=>$x)if($x>0){$first=$i;break;}
                $size=(float)$s[$first];$interval=$first+1;$gap=0; $alpha=.2;
                for($i=$first+1;$i<$n;$i++){ $gap++;if($s[$i]>0){$size=$alpha*$s[$i]+(1-$alpha)*$size;$interval=$alpha*$gap+(1-$alpha)*$interval;$gap=0;} }
                return max(0,(1-$alpha/2)*$size/max(1,$interval));
        }
        return 0.;
    }
}
