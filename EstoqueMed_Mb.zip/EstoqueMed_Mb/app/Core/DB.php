<?php
declare(strict_types=1);
namespace EstoqueMed\Core;
use PDO;
use RuntimeException;

final class DB {
    private static ?PDO $pdo = null;
    public static function get(): PDO {
        if (self::$pdo) return self::$pdo;
        if (!is_file(dirname(__DIR__, 2).'/.env') && getenv('DB_NAME')===false) throw new RuntimeException('Conexão não configurada. Execute INSTALAR.bat.');
        $host = getenv('DB_HOST') ?: '127.0.0.1';
        $port = (int)(getenv('DB_PORT') ?: '3306');
        $db = getenv('DB_NAME') ?: 'estoquemed_mb';
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $db)) throw new RuntimeException('Nome de banco inválido.');
        if (!extension_loaded('pdo_mysql')) throw new RuntimeException('Extensão pdo_mysql não está habilitada neste PHP.');
        return self::$pdo = new PDO("mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4", getenv('DB_USER') ?: 'root', getenv('DB_PASSWORD') ?: '', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_PERSISTENT => false,
            PDO::ATTR_TIMEOUT => 6
        ]);
    }
    public static function all(string $sql, array $params=[]): array { $s=self::get()->prepare($sql); $s->execute($params); return $s->fetchAll(); }
    public static function one(string $sql, array $params=[]): ?array { $s=self::get()->prepare($sql); $s->execute($params); return $s->fetch() ?: null; }
    public static function run(string $sql, array $params=[]): int { $s=self::get()->prepare($sql); $s->execute($params); return $s->rowCount(); }
    public static function scalar(string $sql, array $params=[]): mixed { $s=self::get()->prepare($sql); $s->execute($params); return $s->fetchColumn(); }
    public static function transaction(callable $fn): mixed { $p=self::get(); $p->beginTransaction(); try { $result=$fn($p); $p->commit(); return $result; } catch (\Throwable $e) { if ($p->inTransaction()) $p->rollBack(); throw $e; } }
}
