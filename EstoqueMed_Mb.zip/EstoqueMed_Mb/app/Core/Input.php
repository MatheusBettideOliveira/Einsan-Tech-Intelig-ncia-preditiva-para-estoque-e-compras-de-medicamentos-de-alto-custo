<?php
declare(strict_types=1);
namespace EstoqueMed\Core;
final class Input {
    public static function json(): array { $body=file_get_contents('php://input'); $data=json_decode($body?:'{}',true); if (!is_array($data)) throw new HttpException(400,'JSON inválido.'); return $data; }
    public static function str(array $v,string $key,int $max=255,bool $required=true):string { $raw=$v[$key]??null; if($raw!==null && !is_scalar($raw))throw new HttpException(422,'Campo inválido: '.$key); $s=trim((string)($raw??'')); if (($required&&$s==='')||mbLen($s)>$max) throw new HttpException(422,'Campo inválido: '.$key); return $s; }
    public static function num(array $v,string $key,float $min=0,float $max=100000000):float { if (!isset($v[$key])||!is_numeric($v[$key])) throw new HttpException(422,'Número inválido: '.$key); $n=(float)$v[$key]; if(!is_finite($n)||$n<$min||$n>$max) throw new HttpException(422,'Fora dos limites: '.$key); return $n; }
    public static function int(array $v,string $key,int $min=0,int $max=100000000):int { if (!isset($v[$key])||filter_var($v[$key],FILTER_VALIDATE_INT)===false) throw new HttpException(422,'Inteiro inválido: '.$key); $n=(int)$v[$key]; if($n<$min||$n>$max) throw new HttpException(422,'Fora dos limites: '.$key); return $n; }
    public static function date(string $s): string { $d=\DateTimeImmutable::createFromFormat('!Y-m-d',$s); if(!$d||$d->format('Y-m-d')!==$s) throw new HttpException(422,'Data inválida.'); return $s; }
}
function mbLen(string $v):int { return function_exists('mb_strlen') ? mb_strlen($v) : strlen($v); }
