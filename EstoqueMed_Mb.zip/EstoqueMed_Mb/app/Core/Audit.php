<?php
declare(strict_types=1);
namespace EstoqueMed\Core;
final class Audit {
 public static function log(string $action,string $entity,string $id,array $data=[]):void {
    DB::run('INSERT INTO audit_logs(user_id,action,entity,entity_id,payload,ip_address) VALUES(?,?,?,?,?,?)',[
        Auth::user()['id']??null,$action,$entity,$id,json_encode($data,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE),substr((string)($_SERVER['REMOTE_ADDR']??'cli'),0,45)
    ]);
 }
}
