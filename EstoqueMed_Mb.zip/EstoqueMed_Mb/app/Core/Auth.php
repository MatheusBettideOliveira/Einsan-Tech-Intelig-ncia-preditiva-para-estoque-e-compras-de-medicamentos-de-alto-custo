<?php
declare(strict_types=1);
namespace EstoqueMed\Core;
use RuntimeException;

final class Auth {
    private const ROLE_PERMISSIONS = [
        'admin'=>['*'],
        'purchaser'=>['view','buy','simulate','report'],
        'pharmacist'=>['view','stock','catalog','simulate','report','temperature'],
        'auditor'=>['view','report','audit'],
        'viewer'=>['view','report']
    ];
    public static function user(): ?array { return $_SESSION['user'] ?? null; }
    public static function require(string $permission='view'): array {
        $user=self::user();
        if (!$user) throw new HttpException(401,'Sessão necessária.');
        if (time() - (int)($_SESSION['last_active']??0) > 1800) { self::logout(); throw new HttpException(401,'Sessão expirada.'); }
        $_SESSION['last_active'] = time();
        $allowed = self::ROLE_PERMISSIONS[$user['role']] ?? [];
        if (!in_array('*',$allowed,true) && !in_array($permission,$allowed,true)) throw new HttpException(403,'Sem permissão para esta operação.');
        return $user;
    }
    public static function can(string $permission): bool {
        $r=self::user()['role']??'';
        $allowed=self::ROLE_PERMISSIONS[$r]??[];
        return in_array('*',$allowed,true)||in_array($permission,$allowed,true);
    }
    public static function csrf(): string { if (!isset($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
    public static function verifyCsrf(): void { if (!hash_equals(self::csrf(),(string)($_SERVER['HTTP_X_CSRF_TOKEN']??''))) throw new HttpException(419,'Token CSRF inválido.'); }
    public static function login(string $email,string $password): array {
        $email=strtolower(trim($email));
        if (!filter_var($email,FILTER_VALIDATE_EMAIL)) throw new HttpException(422,'E-mail inválido.');
        $ip=substr((string)($_SERVER['REMOTE_ADDR']??'local'),0,45);
        $key=hash('sha256',$email.'|'.$ip);
        $attempt=DB::one('SELECT * FROM login_attempts WHERE attempt_key=?',[$key]);
        if ($attempt && $attempt['locked_until'] && strtotime($attempt['locked_until'])>time()) throw new HttpException(429,'Acesso temporariamente bloqueado.');
        $user=DB::one('SELECT id,name,email,password_hash,role,active FROM users WHERE email=? LIMIT 1',[$email]);
        if (!$user || !$user['active'] || !password_verify($password,$user['password_hash'])) {
            if ($attempt) {
                $count=strtotime($attempt['last_attempt'])<time()-900?1:(int)$attempt['attempts']+1;
                DB::run('UPDATE login_attempts SET attempts=?,last_attempt=NOW(),locked_until=IF(? >= 5,DATE_ADD(NOW(),INTERVAL 15 MINUTE),NULL) WHERE attempt_key=?',[$count,$count,$key]);
            }
            else DB::run('INSERT INTO login_attempts(attempt_key,attempts,last_attempt) VALUES(?,1,NOW())',[$key]);
            Audit::log('auth.failed','login',$email);
            throw new HttpException(401,'Credenciais inválidas.');
        }
        DB::run('DELETE FROM login_attempts WHERE attempt_key=?',[$key]);
        session_regenerate_id(true);
        $_SESSION=['user'=>['id'=>(int)$user['id'],'name'=>$user['name'],'email'=>$user['email'],'role'=>$user['role']],'csrf'=>bin2hex(random_bytes(32)),'last_active'=>time()];
        DB::run('UPDATE users SET last_login=NOW() WHERE id=?',[$user['id']]);
        Audit::log('auth.login','users',(string)$user['id']);
        return $_SESSION['user'];
    }
    public static function logout(): void { $_SESSION=[]; if (session_status()===PHP_SESSION_ACTIVE) session_regenerate_id(true); }
}
