<?php
declare(strict_types=1);
namespace EstoqueMed\Core;

final class Bootstrap {
    public static function init(bool $web = true): void {
        spl_autoload_register(static function (string $name): void {
            $prefix = 'EstoqueMed\\';
            if (str_starts_with($name, $prefix)) {
                $relative = str_replace('\\', '/', substr($name, strlen($prefix)));
                 
                $base = dirname(__DIR__, 2);
                $path = str_starts_with($relative, 'Seeds/')
                    ? $base . '/seeds/' . substr($relative, strlen('Seeds/')) . '.php'
                    : $base . '/app/' . $relative . '.php';
                if (is_file($path)) require_once $path;
            }
        });
        $env = dirname(__DIR__, 2) . '/.env';
        if (is_file($env) && is_readable($env)) {
            foreach (file($env, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                $line = trim($line);
                if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
                [$key, $value] = explode('=', $line, 2);
                $key = trim($key);
                if (!preg_match('/^[A-Z][A-Z0-9_]*$/', $key)) continue;
                $value = trim($value);
                if (strlen($value) >= 2 && ($value[0] === '"' || $value[0] === "'")) {
                    $quote = $value[0];
                    if (substr($value, -1) === $quote) {
                        $value = substr($value, 1, -1);
                        if ($quote === '"') $value = str_replace(['\\"', '\\\\'], ['"', '\\'], $value);
                    }
                }
                putenv($key . '=' . $value);
            }
        }
        date_default_timezone_set(getenv('APP_TIMEZONE') ?: 'America/Sao_Paulo');
        if ($web) {
            ini_set('display_errors', '0');
            ini_set('log_errors', '1');
            ini_set('session.use_strict_mode', '1');
            ini_set('session.use_only_cookies', '1');
            ini_set('session.cookie_httponly', '1');
            $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
            session_name('estoquemed_session');
            session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);
            if (session_status() !== PHP_SESSION_ACTIVE) session_start();
            header('X-Content-Type-Options: nosniff');
            header('Referrer-Policy: same-origin');
            header('X-Frame-Options: DENY');
            header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
            header("Content-Security-Policy: default-src 'self'; connect-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");
        }
    }
}
