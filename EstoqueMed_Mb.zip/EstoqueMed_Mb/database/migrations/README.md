# Migração inicial

A versão demonstrativa inicia diretamente pelo `database/schema.sql`, executado pelo instalador PHP. Não há migrações incrementais versionadas nesta entrega; para bancos já existentes, **não aplique o instalador por cima**. Faça backup e prepare migração validada caso evolua o modelo de dados.
